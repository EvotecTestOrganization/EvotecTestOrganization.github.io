﻿This library contains all dependencies you will need for this project.
Some of them are installed and registered through the Project Server 2013 SDK, and the SharePoint Server 2013 Client Components SDK.
URL where you can find these tools and some help:
http://www.microsoft.com/en-us/download/details.aspx?id=35585
http://blogs.msdn.com/b/project_programmability/archive/2013/03/19/march-2013-update-of-the-project-2013-sdk-download-file.aspx
