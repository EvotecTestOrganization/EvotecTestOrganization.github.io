﻿Import-Module "C:\[PathHere]\microsoft.sharepointonline.csom.16.1.6906.1200 (1)\lib\net40-full\Microsoft.ProjectServer.Client.dll"
#Set PWA details - update for correct URL, username and password
$PWAInstanceURL = "https://[PathHere].sharepoint.com/sites/pwa"
$PWAUserName = "[UserNameHere]"
$securePass = Read-Host -Prompt "Enter password" -AsSecureString
$csvPath = "C:\[PathHere]\ProjectBulkUpdate.csv"

$projContext = New-Object Microsoft.ProjectServer.Client.ProjectContext($PWAInstanceURL)
[Microsoft.SharePoint.Client.SharePointOnlineCredentials]$spocreds = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($PWAUserName, $securePass); 
$projContext.Credentials = $spocreds

#load projects
$projContext.Load($projContext.Projects)
$projContext.ExecuteQuery() 

# Protect Native attributes from update which should be project pro controlled
$allowedNativeFields = "Description","ProjectIdentifier"

#Import CSV file and update associated project - update location for CSV file 
$updates = Import-Csv $csvPath

$fieldsToUpdate = @()
$fieldsInFile = $updates | Get-Member -MemberType NoteProperty | select -ExpandProperty Name
if ($fieldsInFile -contains "Project ID") {$fieldsInFile +="ProjectIdentifier"} else {$false}
$fieldsInFile | %{
    $fieldInFile = $allFields | Where-Object -Property Name -EQ -Value $_
    If (($fieldInFile.FieldType -eq "Native") -and ($allowedNativeFields -contains $fieldInFile.Name)) {
        $fieldsToUpdate +=$fieldInFile
    } elseIf ($fieldInFile.FieldType -eq "Custom") {
        $fieldsToUpdate +=$fieldInFile
    }
}

$updates | ForEach-Object {
    $update = $_
    try {        
        $projectName = $update."Project Name"
        $project = $projContext.Projects | select Id, Name | where {$_.Name -eq $projectName}
        if($project -ne $null){
            $proj = $projContext.Projects.GetByGuid($project.Id)
            $draftProject = $proj.CheckOut()
            
            $fieldsToUpdate | Foreach-Object {
                $fieldToUpdate = $_
                If ($fieldToUpdate.FieldType -eq "Native"){
                    If ($fieldToUpdate.Name -eq "ProjectIdentifier") {
                        $draftProject.$($fieldToUpdate.Name) = $update."Project ID"
                    } else {$draftProject.$($fieldToUpdate.Name) = $($update.$($fieldToUpdate.Name))}
                } elseif (($fieldToUpdate.FieldType -eq "Custom") -and ($fieldToUpdate.HasLookup -eq $false)){
                    $draftProject.SetCustomFieldValue($fieldToUpdate.InternalName,$update.$($fieldToUpdate.Name))
                } elseif (($fieldToUpdate.FieldType -eq "Custom") -and ($fieldToUpdate.HasLookup -eq $true)) {
                    $draftProject.SetCustomFieldValue($fieldToUpdate.InternalName,[array]$fieldToUpdate.Entries.$($update.$($fieldToUpdate.Name)))
                } else {
                    Write-Warning "Couldn't determine a field mapping"
                }
            }
            $draftProject.Publish($true) | Out-Null
            $projContext.ExecuteQuery()
        }
    } catch {
        write-host -ForegroundColor Red "Add error occurred whilst attempting to update project: '$projectName'. The error details are: $($_)"
    }
}

# dump changes and checkin if error. Try to find which fields are required and report on them before starting or output those rows as a csv to the same directory.