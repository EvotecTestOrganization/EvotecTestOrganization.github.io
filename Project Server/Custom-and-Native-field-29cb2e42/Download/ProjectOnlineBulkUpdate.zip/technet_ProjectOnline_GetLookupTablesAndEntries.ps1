﻿Import-Module "C:\[PathHere]\Microsoft.ProjectServer.Client.dll"
Import-Module "C:\[PathHere]\Microsoft.SharePoint.Client.dll"
$PWAURL = "https://[PathHere].sharepoint.com/sites/pwa"
$PWAUserName = "[UserNameHere]"
$securePass = Read-Host -Prompt "Enter password" -AsSecureString 

$LookupTablesAndEntries = @()
$allFields = @()

# Get the Custom Fields
$url = $PWAURL +"/_api/ProjectServer/CustomFields"
    [Microsoft.SharePoint.Client.SharePointOnlineCredentials]$spocreds = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($PWAUserName, $securePass);    
    $webrequest = [System.Net.WebRequest]::Create($url)
    $webrequest.Credentials = $spocreds
    $webrequest.Accept = "application/json;odata=verbose"
    $webrequest.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f")
    $response = $webrequest.GetResponse()
    $reader = New-Object System.IO.StreamReader $response.GetResponseStream()
    $data = $reader.ReadToEnd()
    $results = ConvertFrom-Json -InputObject $data
    
    $CustomFields = $results.d.results
        $CustomFields | %{
        $CustomField = New-Object -TypeName System.Object
        $CustomField | Add-Member -Type NoteProperty -Name Name -Value $_.Name
        $CustomField | Add-Member -Type NoteProperty -Name FieldType -Value "Custom"
        $CustomField | Add-Member -Type NoteProperty -Name InternalName -Value $_.InternalName
        
        # Find lookup table
        $url = $_.LookupTable.__deferred.uri
            [Microsoft.SharePoint.Client.SharePointOnlineCredentials]$spocreds = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($PWAUserName, $securePass);    
            $webrequest = [System.Net.WebRequest]::Create($url)
            $webrequest.Credentials = $spocreds
            $webrequest.Accept = "application/json;odata=verbose"
            $webrequest.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f")
            $response = $webrequest.GetResponse()
            $reader = New-Object System.IO.StreamReader $response.GetResponseStream()
            $data = $reader.ReadToEnd()
            $results = ConvertFrom-Json -InputObject $data
        $HasLookup = [bool]$results.d.Name
        $CustomField | Add-Member -Type NoteProperty -Name HasLookup -Value $HasLookup
        If ($HasLookup -eq $true) {
            $CustomField | Add-Member -Type NoteProperty -Name LookupTable -Value $results.d.Name
            #$CustomField | Add-Member -Type NoteProperty -Name Id -Value $results.d.Id
            $url = $results.d.Entries.__deferred.uri
                [Microsoft.SharePoint.Client.SharePointOnlineCredentials]$spocreds = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($PWAUserName, $securePass);    
                $webrequest = [System.Net.WebRequest]::Create($url)
                $webrequest.Credentials = $spocreds
                $webrequest.Accept = "application/json;odata=verbose"
                $webrequest.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f")
                $response = $webrequest.GetResponse()
                $reader = New-Object System.IO.StreamReader $response.GetResponseStream()
                $data = $reader.ReadToEnd()
                $results = ConvertFrom-Json -InputObject $data
            $Entries = $results.d.results
            $EntryHash = @{}
            $Entries | %{$EntryHash.Add($_.FullValue, $_.Id)}
            $CustomField | Add-Member -Type NoteProperty -Name Entries -Value $EntryHash
        }
        $allFields += $CustomField
    }

# Get the Native Fields
$url = $PWAURL +"/_api/ProjectServer/Projects"
    [Microsoft.SharePoint.Client.SharePointOnlineCredentials]$spocreds = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($PWAUserName, $securePass);    
    $webrequest = [System.Net.WebRequest]::Create($url)
    $webrequest.Credentials = $spocreds
    $webrequest.Accept = "application/json;odata=verbose"
    $webrequest.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f")
    $response = $webrequest.GetResponse()
    $reader = New-Object System.IO.StreamReader $response.GetResponseStream()
    $data = $reader.ReadToEnd()
    $results = ConvertFrom-Json -InputObject $data
    $NativeFields = $results.d.results | Get-Member -MemberType NoteProperty | Select-Object Name,@{name="FieldType";expression={"Native"}}
    $allFields += $NativeFields 

$allFields | Where-Object -Property HasLookup -EQ $true | %{
    Write-Host -BackgroundColor Gray $_.Name
    $_.Entries.keys
}