﻿using System;
using System.Text.RegularExpressions;

namespace DemandManagement.BulkEditTool
{
    public static class GuidExtensions
    {
        public static bool TryParse(this Guid guid, string s, out Guid result)
        {
            const string guidMatchPattern = "^[A-Fa-f0-9]{32}$|" +
                                             "^({|\\()?[A-Fa-f0-9]{8}-([A-Fa-f0-9]{4}-){3}[A-Fa-f0-9]{12}(}|\\))?$|" +
                                             "^({)?[0xA-Fa-f0-9]{3,10}(, {0,1}[0xA-Fa-f0-9]{3,6}){2}, {0,1}({)([0xA-Fa-f0-9]{3,4}, {0,1}){7}[0xA-Fa-f0-9]{3,4}(}})$";
            if (string.IsNullOrEmpty(s) || !(new Regex(guidMatchPattern)).IsMatch(s))
            {
                result = Guid.Empty;
                return false;
            }
            result = new Guid(s);
            return true;
        }
    }
}
