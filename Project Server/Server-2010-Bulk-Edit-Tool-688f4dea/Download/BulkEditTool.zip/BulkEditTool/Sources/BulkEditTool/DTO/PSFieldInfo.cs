﻿using System;
using Microsoft.Office.Project.Server.Library;

namespace DemandManagement.BulkEditTool.DTO
{
    public class PSFieldInfo
    {
        public Guid Uid { get; set; }
        public string Name { get; set; }
        public string IntrinsicName { get; set; }
        public int IsCustomField { get; set; }
        public PSDataType DataType { get; set; }
        public bool IsMultiValue { get; set; }
        public Guid? LookupTableUid { get; set; }
        public bool IsLeafOnly { get; set; }
        public bool IsFormula { get; set; }
        public string GraphicalIndicator { get; set; }
        public bool IsMultiline { get; set; }
        //public LookupTableInfo LookupTableInfo { get; set; }
    }
}
