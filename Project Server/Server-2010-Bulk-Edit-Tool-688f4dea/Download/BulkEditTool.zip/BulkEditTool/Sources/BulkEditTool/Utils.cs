﻿using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace DemandManagement.BulkEditTool
{
    public static class Utils
    {
        public static bool ServerCertificateValidation(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors error)
        {
            return true;
        }
    }
}
