﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using DemandManagement.BulkEditTool.WebSvcLookupTable;
using Microsoft.Office.Project.PWA;
using Microsoft.Office.Project.Server.Library;
using DemandManagement.BulkEditTool.DTO;
using Microsoft.SharePoint;

namespace DemandManagement.BulkEditTool.Services
{
    public class LookupTablesService
    {
        private const int DEFAULT_LANG_ID = 0;
        private readonly Dictionary<Guid, string> _ltValues = new Dictionary<Guid, string>();

        internal const string WebServiceUrl = "LookupTable.asmx";

        private WebSvcLookupTable.LookupTable _wssLookupTable;

        public LookupTablesService()
        {
            _wssLookupTable = new WebSvcLookupTable.LookupTable
            {
                Url =
                    string.Format("{0}{1}{2}", SPContext.Current.Site.Url, "/_vti_bin/psi/", WebServiceUrl),
                Credentials = CredentialCache.DefaultCredentials,
                CookieContainer = new CookieContainer()
            };
        }

        public string GetLookupItem(Guid ltUid, Guid itemUid)
        {
            if (!_ltValues.ContainsKey(itemUid))
            {
                using (var dsLookupTables = _wssLookupTable.ReadLookupTablesByUids(
                    new[] {ltUid},
                    false,
                    DEFAULT_LANG_ID))
                {
                    dsLookupTables.LookupTableTrees.Rows
                        .Cast<LookupTableDataSet.LookupTableTreesRow>()
                        .ToList()
                        .ForEach(_ => _ltValues[_.LT_STRUCT_UID] = _.LT_VALUE_FULL);
                }
            }
            return _ltValues[itemUid];
        }

        public Dictionary<Guid, object> GetLookupItems(PSFieldInfo lookupField)
        {
            var items = new Dictionary<Guid, object>();
            using (var dsLookupTables = PJContext.Current.PSI.LookupTableWebService.ReadLookupTablesByUids(
                    new[] { lookupField.LookupTableUid.Value },
                    false,
                    DEFAULT_LANG_ID))
            {
                dsLookupTables.LookupTableTrees.Rows
                    .Cast<LookupTableDataSet.LookupTableTreesRow>()
                    .ToList()
                    .ForEach(_ => items.Add(_.LT_STRUCT_UID, GetLookupItemData(lookupField, _)));
            }

            return items;
        }

        private object GetLookupItemData(PSFieldInfo lookupField, LookupTableDataSet.LookupTableTreesRow row)
        {
            switch (lookupField.DataType)
            {
                case PSDataType.COST:
                case PSDataType.NUMBER:
                    return row.LT_VALUE_NUM;
                case PSDataType.DURATION:
                    return row.LT_VALUE_DUR;
                case PSDataType.DATE:
                    return row.LT_VALUE_DATE;
                case PSDataType.STRING:
                    return row.LT_VALUE_FULL;
                default:
                    throw new ArgumentException(string.Format("Cannot get lookup value for type {0}", lookupField.DataType));
            }
        }
    }
}
