﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using DemandManagement.BulkEditTool.DTO;
using DemandManagement.BulkEditTool.WebSvcView;
using Microsoft.Office.Project.PWA;
using Microsoft.Office.Project.Server.Library;
using Microsoft.SharePoint;

namespace DemandManagement.BulkEditTool.Services
{
    public class FieldsService
    {
        internal const string WebServiceUrl = "View.asmx";

        private WebSvcView.View _wssView;

        public FieldsService()
        {
            _wssView = new WebSvcView.View
                           {
                               Url =
                                   string.Format("{0}{1}{2}", SPContext.Current.Site.Url, "/_vti_bin/psi/", WebServiceUrl),
                               Credentials = CredentialCache.DefaultCredentials,
                               CookieContainer = new CookieContainer()
                           };
        }

        public IEnumerable<PSFieldInfo> GetProjectFields()
        {
            //read all custom and intrinsic fields)
            using (var ds = _wssView.ReadPortfolioFields())
            {
                //transform to PSFieldInfo structures list
                var fieldInfos = ds.ViewFields.Rows
                    .Cast<ViewFieldsDataSet.ViewFieldsRow>()
                    .Select(_ => new PSFieldInfo
                                     {
                                         Uid = _.WFIELD_UID,
                                         Name = _.CONV_STRING,
                                         IntrinsicName = _.WFIELD_NAME_SQL,
                                         IsCustomField = _.WFIELD_IS_CUSTOM_FIELD,
                                         DataType = (PSDataType)_.WFIELD_TEXTCONV_TYPE,
                                         IsMultiValue =
                                             _.IsWFIELD_IS_MULTI_VALUENull() ? false : _.WFIELD_IS_MULTI_VALUE,
                                         LookupTableUid = _.IsWFIELD_LOOKUP_TABLE_UIDNull()
                                                              ? (Guid?)null
                                                              : _.WFIELD_LOOKUP_TABLE_UID,
                                         IsMultiline = !_.IsWFIELD_IS_MULTILINE_TEXTNull() && _.WFIELD_IS_MULTILINE_TEXT,
                                     })
                    .ToList();
                
                //add Description field because it is not present in Portfolio fields
                fieldInfos.Add(new PSFieldInfo
                                   {
                                       Uid = new Guid("837aafa9-fa1a-49c0-8a08-6b007865991b"),
                                       DataType = PSDataType.STRING,
                                       IntrinsicName = "WPROJ_DESCRIPTION",
                                       IsCustomField = 0,
                                       IsMultiline = true,
                                       Name = "Description"
                                   });

                fieldInfos = fieldInfos.OrderBy(_ => _.Name).ToList();
                //fill the lacking data from CustomFields service
                //(only for custom fields)
                FillCFInfos(fieldInfos.Where(_ => _.IsCustomField == 1).ToList());

                return fieldInfos;
            }
        }

        private static void FillCFInfos(List<PSFieldInfo> fileldInfos)
        {
            var mdPropUids = fileldInfos.Select(_ => _.Uid).ToArray();
            using (var ds = PJContext.Current.PSI.CustomFieldsWebService.ReadCustomFieldsByMdPropUids(mdPropUids, false))
            {
                fileldInfos.ForEach(fieldInfo =>
                                        {
                                            var cfRow = ds.CustomFields.FindByMD_PROP_UID(fieldInfo.Uid);
                                            if (!cfRow.IsMD_PROP_IS_LEAF_NODE_ONLYNull())
                                                fieldInfo.IsLeafOnly = cfRow.MD_PROP_IS_LEAF_NODE_ONLY;
                                            fieldInfo.IsFormula = !cfRow.IsMD_PROP_FORMULANull();
                                            if (!cfRow.IsMD_PROP_GRAPHICAL_INDICATORNull())
                                                fieldInfo.GraphicalIndicator = cfRow.MD_PROP_GRAPHICAL_INDICATOR;
                                        });
            }
        }
    }
}
