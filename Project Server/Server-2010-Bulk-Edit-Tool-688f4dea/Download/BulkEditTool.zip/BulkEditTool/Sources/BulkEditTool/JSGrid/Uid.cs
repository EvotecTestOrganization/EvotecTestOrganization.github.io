﻿using System;

namespace DemandManagement.BulkEditTool.JSGrid
{
    public class Uid : IComparable
    {
        public Guid Guid { get; set; }

        public Uid(Guid guid)
        {
            Guid = guid;
        }

        public override string ToString()
        {
            return string.Format("guid<;>{0:D}", Guid);
        }

        public int CompareTo(object obj)
        {
            return Guid.CompareTo(obj != null ? ((Uid)obj).Guid : (Guid?)null);
        }

        public static implicit operator Uid(Guid guid)
        {
            return new Uid(guid);
        }
    }
}
