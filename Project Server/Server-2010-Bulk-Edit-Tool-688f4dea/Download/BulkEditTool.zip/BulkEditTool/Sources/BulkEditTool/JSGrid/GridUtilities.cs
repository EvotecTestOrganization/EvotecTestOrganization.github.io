﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using DemandManagement.BulkEditTool.DTO;
using DemandManagement.BulkEditTool.Services;
using Microsoft.Office.Project.PWA;
using Microsoft.Office.Project.Server.Library;
using Microsoft.Office.Project.Server.Schema;
using Microsoft.SharePoint;
using Microsoft.SharePoint.JSGrid;
using Microsoft.SharePoint.JsonUtilities;
using BETResources = DemandManagement.BulkEditTool.GlobalResources.BulkEditTool;

namespace DemandManagement.BulkEditTool.JSGrid
{
    public static class GridUtilities
    {
        public static LookupTypeInfo YesNoUnknownlookupTypeInfo = new LookupTypeInfo(
            "YesNoUnknownlookup",
            new List<LookupTypeItem>
                {
                    new LookupTypeItem(FLAG_UNKNOWN_VALUE, BETResources.UNKNOWN),
                    new LookupTypeItem(1, BETResources.YES),
                    new LookupTypeItem(0, BETResources.NO)
                });

        private static readonly object _syncObj = new object();

        private static LookupTypeInfo _projectTypeLookupTypeInfo;
        public static LookupTypeInfo ProjectTypeLookupTypeInfo
        {
            get
            {
                lock(_syncObj)
                {
                    if(_projectTypeLookupTypeInfo == null)
                    {
                        var projectTypes = new List<LookupTypeItem>();
                        
                        PJContext.Current.PSI.WorkflowWebService.ReadEnterpriseProjectTypeList()
                            .EnterpriseProjectType.Rows
                            .Cast <WorkflowDataSet.EnterpriseProjectTypeRow>()
                            .ToList()
                            .ForEach(_ => projectTypes.Add(new LookupTypeItem(_.ENTERPRISE_PROJECT_TYPE_UID.ToString(), _.ENTERPRISE_PROJECT_TYPE_NAME)));

                        _projectTypeLookupTypeInfo = new LookupTypeInfo("ProjectTypeLookup", projectTypes);
                    }
                }

                return _projectTypeLookupTypeInfo;
            }
        }

        public const int FLAG_UNKNOWN_VALUE = -1;
        public const string KEY_COLUMN_NAME = "Key";
        public const string PROJ_NAME_COLUMN_NAME = "PROJ_NAME";
        public const string IS_PROJECT_EDITABLE_COLUMN_NAME = "IsProjectEditable";

        public static IList<GridColumn> GetGridColumns(DataTable table)
        {
            return table.Columns
                .Cast<DataColumn>()
                .Where(_ => _.ColumnName != KEY_COLUMN_NAME
                            && _.ColumnName != IS_PROJECT_EDITABLE_COLUMN_NAME
                            && _.ColumnName != GridSerializer.DefaultGridRowStyleIdColumnName)
                .Select(_ =>
                            {
                                var column = new GridColumn {FieldKey = _.ColumnName, Name = _.Caption};

                                if (_.ColumnName != KEY_COLUMN_NAME)
                                {
                                    column.Width = 100;
                                }
                                column.IsHidable = _.ColumnName != PROJ_NAME_COLUMN_NAME;

                                if (_.ColumnName == PROJ_NAME_COLUMN_NAME)
                                    column.IsSortable = true;
                                return column;
                            })
                .ToList();
        }

        public static IList<GridField> GetGridFields(DataTable table, bool isEditMode)
        {
            return table.Columns
                .Cast<DataColumn>()
                .Select(column => new {column, field = new GridField()})
                .Select(_ => FormatGridField(_.field, _.column, isEditMode))
                .ToList();
        }

        private static readonly List<Guid> _readOnlyFields = new List<Guid>
            {
                new Guid("7f75e6cb-5942-4dfa-b255-2dac319d0b74"), //Author
                new Guid("d208755a-fa29-46ee-a6ab-990fb59d6dbe"), //Checked Out
                new Guid("f8ff56af-c14e-4e68-9c2a-9a044c3d5a17"), //Checked Out By
                new Guid("0000dd7f-e625-427f-ba00-8ba66a1f9def"), //Workflow Phase Name
                new Guid("0000574e-ce35-4550-a53e-ae3be7eb626c"), //Workflow Stage Name
                new Guid("b7af60fb-592a-4656-a324-4beb4330f2a2"), //Workflow State
            };

        public static GridField FormatGridField(GridField gf, DataColumn dc, bool isEditMode)
        {
            if(dc.ColumnName == GridSerializer.DefaultGridRowStyleIdColumnName)
            {
                gf.FieldKey = dc.ColumnName;
                gf.SerializeDataValue = true;
                return gf;
            }
            //set field key name
            gf.FieldKey = dc.ColumnName;
            var cfInfo = (PSFieldInfo) dc.ExtendedProperties[GridData.EXT_PROP_FIELD_INFO];

            gf.EditMode = cfInfo != null &&
                          (cfInfo.IsFormula ||
                          _readOnlyFields.Contains(cfInfo.Uid) ||
                          cfInfo.IsCustomField == 0 && cfInfo.IntrinsicName.StartsWith("TASK") && !cfInfo.IntrinsicName.Equals("TASK_START_DATE"))
                              ? EditMode.ReadOnly
                              : EditMode.ReadWriteDefer;

            //when in doubt serialize the data value
            gf.SerializeDataValue = true;
            if (dc.ColumnName != KEY_COLUMN_NAME &&
                dc.ColumnName!=IS_PROJECT_EDITABLE_COLUMN_NAME)
            {
                //add properties based on the type


                if (cfInfo.Uid == new Guid("759c6ad4-aaa3-4b50-9522-548229854cd8")) //Project Owner
                {
                    gf.PropertyTypeId = "ProjectOwnerPropType";
                    /*The Localizer determines how we render the underlying data on screen */
                    gf.Localizer = delegate(DataRow row, object toConvert)
                    {
                        return
                            PJContext.Current.PSI.ResourceWebService.ReadResource(new Guid(toConvert.ToString())).Resources[0].
                                RES_NAME;
                    };
                    /*The Serialization type is a required property */
                    gf.SerializeLocalizedValue = true;
                    gf.SerializeDataValue = true;
                }
                else if (cfInfo.Uid == new Guid("0000bfd3-64ea-43cc-aa00-e1289615a7a1")) //Enterprise Project Type Name
                {
                    //show yes/no/unknown dropdown
                    gf.AssociateWithLookupTypeInfo(ProjectTypeLookupTypeInfo);
                    gf.SerializeDataValue = true;
                    gf.SerializeLocalizedValue = true;
                    gf.Localizer = delegate(DataRow row, object toConvert)
                    {
                        return ProjectTypeLookupTypeInfo.Lookup.First(_ => _.Value.Equals(toConvert)).LocalString;
                    };
                }
                else if (dc.DataType == typeof(String) && cfInfo.IsMultiline || cfInfo.Uid == new Guid("837aafa9-fa1a-49c0-8a08-6b007865991b") /*Description*/)
                {
                    gf.PropertyTypeId = "RichTextPropType";
                    /*The Localizer determines how we render the underlying data on screen */
                    gf.Localizer = delegate(DataRow row, object toConvert)
                                       {
                                           return toConvert == null ? "" : toConvert.ToString();
                                       };
                    /*The Serialization type is a required property */
                    gf.SerializeLocalizedValue = true;
                    gf.SerializeDataValue = false;
                }
                else if (dc.DataType == typeof(String))
                {
                    gf.PropertyTypeId = "CustomString";
                    /*The Localizer determines how we render the underlying data on screen */
                    gf.Localizer = delegate(DataRow row, object toConvert)
                                       {
                                           return toConvert == null ? "" : toConvert.ToString();
                                       };
                    /*The Serialization type is a required property */
                    gf.SerializeLocalizedValue = true;
                    gf.SerializeDataValue = false;
                }
                else if (dc.DataType == typeof(Int32))
                {
                    gf.PropertyTypeId = "CustomJSNumber";
                    /*The Localizer determines how we render the underlying data on screen */
                    gf.Localizer = delegate(DataRow row, object toConvert)
                                       {
                                           return toConvert == null ? "" : toConvert.ToString();
                                       };
                    /*The Serialization type is a required property */
                    gf.SerializeLocalizedValue = true;
                    gf.SerializeDataValue = false;
                }
                else if (dc.DataType == typeof(Hyperlink))
                {
                    gf.PropertyTypeId = "Hyperlink";
                    gf.Localizer = delegate(DataRow row, object toConvert)
                                       {
                                           return toConvert == null ? "" : toConvert.ToString();
                                       };
                    gf.SerializeLocalizedValue = false;
                    gf.SerializeDataValue = true;
                }
                else if (dc.DataType == typeof(bool))
                {
                    //show yes/no/unknown dropdown
                    gf.AssociateWithLookupTypeInfo(YesNoUnknownlookupTypeInfo);
                    gf.SerializeDataValue = true;
                    gf.SerializeLocalizedValue = true;
                    gf.Localizer = delegate(DataRow row, object toConvert)
                    {
                        return toConvert == null ? "" : ((bool)toConvert) ? BETResources.YES : BETResources.NO;
                    };
                    
                }
                else if (dc.DataType == typeof(DateTime))
                {
                    gf.PropertyTypeId = "CustomJSDateTime";
                    gf.Localizer = delegate(DataRow row, object toConvert)
                                       {
                                           return toConvert == null ? "" : ((DateTime)toConvert).ToShortDateString();
                                       };
                    gf.SerializeDataValue = true;
                    gf.SerializeLocalizedValue = true;
                }
                else if (dc.DataType == typeof(decimal))
                {
                    gf.PropertyTypeId = "CustomJSNumber";
                    /*The Localizer determines how we render the underlying data on screen */
                    var isCost = cfInfo.DataType == PSDataType.COST;
                    gf.Localizer = isCost && !isEditMode
                                       ? (ValueLocalizer)
                                         ((row, toConvert) => toConvert == null ? "" :string.Format("{0:C}",toConvert))
                                       : ((row, toConvert) => toConvert == null ? "" : toConvert.ToString());
                    /*The Serialization type is a required property */
                    gf.SerializeLocalizedValue = true;
                    gf.SerializeDataValue = false;
                }
                else if (dc.DataType == typeof(TimeSpan))
                {
                    gf.PropertyTypeId = "String";
                    /*The Localizer determines how we render the underlying data on screen */
                    gf.Localizer = delegate(DataRow row, object toConvert)
                    {
                        return toConvert == null ? "" : string.Format("{0:#,##0.##}d", ((TimeSpan)toConvert).TotalDays);
                    };
                    /*The Serialization type is a required property */
                    gf.SerializeLocalizedValue = true;
                    gf.SerializeDataValue = false;
                }
                else if (dc.DataType == typeof(Uid))
                {
                    gf.PropertyTypeId = "String";
                    gf.Localizer = delegate(DataRow row, object toConvert)
                    {
                        if(toConvert == null)
                        {
                            return "";
                        }
                        
                        string lookupItem = null;
                        SPSecurity.RunWithElevatedPrivileges(() => lookupItem = new LookupTablesService().GetLookupItem(cfInfo.LookupTableUid.Value, ((Uid)toConvert).Guid));
                        return lookupItem;
                    };
                    gf.SerializeLocalizedValue = true;
                    gf.SerializeDataValue = true;
                }
                else if (dc.DataType == typeof(List<Uid>))
                {
                    gf.PropertyTypeId = "String[Guid]";
                    gf.MultiValue = true;
                    gf.Localizer = delegate(DataRow row, object toConvert)
                    {
                        string lookupItem = null;
                        SPSecurity.RunWithElevatedPrivileges(() => lookupItem = new LookupTablesService().GetLookupItem(cfInfo.LookupTableUid.Value, ((Uid)toConvert).Guid));
                        return lookupItem;
                    };
                    gf.SerializeLocalizedValue = true;
                    gf.SerializeDataValue = true;
                }
                else
                    throw new Exception("No PropTypeId defined for this datatype" + dc.DataType);

                //graphical indicators for read-only mode
                if (!isEditMode && !string.IsNullOrEmpty(cfInfo.GraphicalIndicator))
                {
                    gf.PropertyTypeId = "GIPropType";
                    ValueLocalizer oldLocalizer = null;
                    if(gf.SerializeLocalizedValue)
                        oldLocalizer = gf.Localizer;

                    gf.Localizer = delegate(DataRow row, object toConvert)
                                       {
                                           var localizedValue = oldLocalizer != null
                                                              ? oldLocalizer(row, toConvert)
                                                              : string.Empty;

                                           int indicatorIndex = 0;
                                           if (toConvert != null)
                                               indicatorIndex = IndicatorHelper.RunIndicatorRules(
                                                   cfInfo.GraphicalIndicator,
                                                   toConvert is Uid ? localizedValue : toConvert,
                                                   cfInfo.DataType);

                                           return new Serializer().SerializeToJson(new {indicatorIndex, localizedValue});
                                       };
                    gf.SerializeLocalizedValue = true;
                    gf.SerializeDataValue = true;
                }
            }
            return gf;
        }

        public static Dictionary<Guid, object> GetCustomFieldInfoObject(IEnumerable<PSFieldInfo> fieldsToShow)
        {
           return FilterLookupFields(fieldsToShow)
                .ToDictionary(
                    _ => _.Uid,
                    _ => (object)new {isRequired = false});
        }

        public static Dictionary<Guid, object> GetCustomFieldLoolupTableInfoObject(IEnumerable<PSFieldInfo> fieldsToShow)
        {
            return FilterLookupFields(fieldsToShow)
                .ToDictionary(
                    _ => _.Uid,
                    _ => (object) new
                                      {
                                          isEnterprise = true,
                                          lookupTableUid = _.LookupTableUid.HasValue ? new Uid(_.LookupTableUid.Value) : null,
                                          leafOnly = _.IsLeafOnly,
                                          multiValue = _.IsMultiValue
                                      });
        }

        private static IEnumerable<PSFieldInfo> FilterLookupFields(IEnumerable<PSFieldInfo> fieldsToShow)
        {
            return fieldsToShow
                .Where(_ => _.IsCustomField == 1 && _.LookupTableUid.HasValue);
        }

    }
}
