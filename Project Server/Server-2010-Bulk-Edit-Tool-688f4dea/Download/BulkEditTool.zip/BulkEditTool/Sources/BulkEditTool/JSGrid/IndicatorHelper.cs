﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Microsoft.Office.Project.Server.Library;

namespace DemandManagement.BulkEditTool.JSGrid
{
    internal class IndicatorRule
    {
        public string Operator { get; set; }
        public string Operand { get; set; }
        public int? Result { get; set; }
    }

    public class IndicatorHelper
    {
        private const string RULES_REGEX = @"(\[\[(.+?)\t(.*?)\t{2}\]\[(.+?)\]\])";

        public static int RunIndicatorRules(string rulesBody, object data, PSDataType dataType)
        {
            try
            {
                var rules = new List<IndicatorRule>();
                rulesBody = rulesBody.Replace("ANY", "ANY\t \t\t");
                var matches = Regex.Matches(rulesBody, RULES_REGEX);
                foreach (Match match in matches)
                {
                    try
                    {
                        rules.Add(new IndicatorRule
                                      {
                                          Operator = match.Groups[2].Value,
                                          Operand = match.Groups[3].Value,
                                          Result = int.Parse(match.Groups[4].Value)
                                      });
                    }
                    catch
                    {
                    }
                }

                foreach (var rule in rules)
                {
                    if (!string.IsNullOrEmpty(rule.Operand) && !string.IsNullOrEmpty(rule.Operator) &&
                        rule.Result.HasValue)
                    {
                        var fixedData = data;

                        if (dataType == PSDataType.COST)
                        {
                            fixedData = ((decimal)data) * 100;
                        }
                        if (TestValue(fixedData, rule.Operator, rule.Operand))
                            return rule.Result.Value;
                    }
                }
            }
            catch
            {
            }
            return 0;
        }

        public static bool TestValue(object data, string testOperator, string strOperand)
        {                        
            var dataType = data.GetType();
            object operand = null;
            try
            {
                operand = Convert.ChangeType(strOperand, dataType);
            }
            catch
            {
                return false;
            }
            var strData = string.Format("{0}", data);

            switch (testOperator)
            {
                case "==":
                    return data.Equals(operand);
                case "!=":
                    return data.Equals(operand);
                case "<":
                    return ((IComparable) data).CompareTo(operand) < 0;
                case "<=":
                    return ((IComparable) data).CompareTo(operand) <= 0;
                case ">":
                    return ((IComparable) data).CompareTo(operand) > 0;
                case ">=":
                    return ((IComparable) data).CompareTo(operand) >= 0;
                case "doesntcontain":
                    return !strData.ToLower().Contains(strOperand.ToLower());
                case "contains":
                    return strData.ToLower().Contains(strOperand.ToLower());
                case "containsexactly":
                    return strData.Contains(strOperand);
                case "any":
                    return true;
                case "beginswith":
                    return strData.StartsWith(strOperand, StringComparison.InvariantCultureIgnoreCase);
                default:
                    if (testOperator.Contains("not"))
                    {
                        return !strData.Contains(strOperand);
                    }
                    else
                    {
                        return strData.Contains(strOperand);
                    }
            }
        }
    }
}
