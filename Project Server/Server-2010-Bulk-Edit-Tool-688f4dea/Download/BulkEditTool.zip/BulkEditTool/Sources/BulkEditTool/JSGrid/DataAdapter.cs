﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using DemandManagement.BulkEditTool.DTO;
using DemandManagement.BulkEditTool.Services;
using Microsoft.Office.Project.PWA;
using Microsoft.Office.Project.Server.Library;
using Microsoft.Office.Project.Server.Schema;
using System.Collections;
using Microsoft.SharePoint;
using Microsoft.SharePoint.JSGrid;

namespace DemandManagement.BulkEditTool.JSGrid
{
    [Flags]
    public enum ProjectEntityType
    {
        Project = 1,
        Task = 2,
        Resource = 4,
        Assignment = 8,
        Dependency = 16,
        ProjectCustomFields = 32,
        TaskCustomFields = 64,
        ResourceCustomFields = 128,
        AssignmentCustomFields = 256,
        AssignmentCore = 512,
        ProjectDefaults = 1024,
        AssignmentOwnerDefaults = 2048,
        AssignmentCustomFieldsNoRolldown = 4096
    }

    public class GridData
    {
        public const string EXT_PROP_FIELD_INFO = "FieldInfo";
        private const DataStoreEnum DATA_STORE = DataStoreEnum.WorkingStore;
        private const int WORK_TIME_BASIS = 3;// 24 / 8

        public DataTable Data(IEnumerable<PSFieldInfo> fieldInfos, IEnumerable<FilterItem> filterBy, Guid[] projectUids, bool isEditMode)
        {
            //create & initialize the datatable
            var table = new DataTable { Locale = System.Globalization.CultureInfo.InvariantCulture };

            //add the columns that we care about
            table.Columns.Add(new DataColumn(GridUtilities.KEY_COLUMN_NAME, typeof(Guid)));
            table.Columns.Add(new DataColumn(GridUtilities.IS_PROJECT_EDITABLE_COLUMN_NAME, typeof(bool)));
            table.Columns.Add(new DataColumn(GridSerializer.DefaultGridRowStyleIdColumnName, typeof(String)));

            foreach (var fieldInfo in fieldInfos)
            {
                var column = new DataColumn(CalculateColumnName(fieldInfo), GetCustomFieldDataType(fieldInfo)) { Caption = fieldInfo.Name };
                column.ExtendedProperties[EXT_PROP_FIELD_INFO] = fieldInfo;
                table.Columns.Add(column);
            }

            //fill data table with projects data
            using (ProjectDataSet dsProject = PJContext.Current.PSI.ProjectWebService.ReadProjectStatus(
                Guid.Empty,
                DATA_STORE,
                string.Empty,
                (int)Project.ProjectType.Project))
            {
                foreach (ProjectDataSet.ProjectRow currentRow in dsProject.Project.Rows)
                {
                    if (!DoesUserHaveProjectPermissions(currentRow.PROJ_UID))
                    {
                        continue;
                    }
                    //skip the project if it is not chosen by user)
                    if (projectUids != null && projectUids.Length > 0 && !projectUids.Contains(currentRow.PROJ_UID))
                        continue;

                    var newRow = table.NewRow();

                    var checkedOutByOther = IsCheckedOutByOtherUser(currentRow);

                    newRow[GridUtilities.KEY_COLUMN_NAME] = currentRow.PROJ_UID;
                    newRow[GridUtilities.IS_PROJECT_EDITABLE_COLUMN_NAME] =
                        (!isEditMode && !checkedOutByOther) ||
                        (isEditMode && TryMakeProjectEditable(currentRow));

                    if (checkedOutByOther)
                        newRow[GridSerializer.DefaultGridRowStyleIdColumnName] = "CheckedOutByOtherUser";

                    if (FillDataTableWithProjects(currentRow.PROJ_UID, fieldInfos, newRow, filterBy))
                        table.Rows.Add(newRow);
                }
            }

            return table;
        }

        public static readonly Guid SaveProjecttoProjectServerPermissionUid = new Guid("bf93a026-deac-4949-be19-c513701139ff");
        public static readonly Guid EditProjectSummaryFieldsPermissionUid = new Guid("0000c768-6d95-4c77-b7db-5d7cdafc1bea");

        private bool DoesUserHaveProjectPermissions(Guid projectUid)
        {
            var allow = PJContext.Current.PSI.SecurityWebService.CheckUserProjectPermissions(
                projectUid,
                new Guid[]
                    {
                        SaveProjecttoProjectServerPermissionUid,
                        EditProjectSummaryFieldsPermissionUid
                    }
            );

            return allow[0] && allow[1];
        }

        private static bool FillDataTableWithProjects(Guid projectUid, IEnumerable<PSFieldInfo> fieldInfos, DataRow newRow, IEnumerable<FilterItem> filterBy)
        {
            using (var dsProject = ReadProjectDataSet(projectUid))
            {
                if (filterBy != null && filterBy.Count() > 0 && !FilterProject(dsProject, filterBy))
                    return false;

                //custom fields
                foreach (ProjectDataSet.ProjectCustomFieldsRow cfRow in dsProject.ProjectCustomFields)
                {
                    Guid mdPropUid = cfRow.MD_PROP_UID;
                    var fieldInfo = fieldInfos.FirstOrDefault(_ => _.Uid == mdPropUid);
                    if (fieldInfo != null)
                    {
                        var columnName = CalculateColumnName(fieldInfo);
                        var customFieldRowData = GetCustomFieldRowData(cfRow, fieldInfo);

                        if (!fieldInfo.IsMultiValue)
                        {
                            newRow[columnName] = customFieldRowData;
                        }
                        else
                        {
                            if (newRow[columnName] == DBNull.Value)
                                newRow[columnName] = new List<Uid>();

                            ((List<Uid>)newRow[columnName]).Add(((Uid)customFieldRowData).Guid);
                        }
                    }
                }

                //native fields
                var projectRow = (ProjectDataSet.ProjectRow)dsProject.Project.Rows[0];
                var taskRow = dsProject.Task.Rows
                    .Cast<ProjectDataSet.TaskRow>()
                    .First(_ => _.PROJ_UID == projectRow.PROJ_UID && !_.IsTASK_IS_SUMMARYNull() && _.TASK_IS_SUMMARY);
                newRow[GridUtilities.KEY_COLUMN_NAME] = projectRow.PROJ_UID;
                foreach (var fieldInfo in fieldInfos)
                {
                    var columnName = CalculateColumnName(fieldInfo);
                    if (fieldInfo.Uid == new Guid("0000bfd3-64ea-43cc-aa00-e1289615a7a1")) // Enterprise Project Type Name
                    {
                        newRow[columnName] = projectRow.ENTERPRISE_PROJECT_TYPE_UID.ToString();
                    }
                    else if (dsProject.Project.Columns.Contains(columnName)
                        && projectRow[columnName] != DBNull.Value)
                    {
                        newRow[columnName] = projectRow[columnName];
                    }
                    else if (dsProject.Task.Columns.Contains(columnName))
                    {
                        newRow[columnName] = taskRow[columnName];
                    }
                    else if(fieldInfo.Uid == new Guid("{759c6ad4-aaa3-4b50-9522-548229854cd8}"))
                    {
                        newRow[columnName] = projectRow.ProjectOwnerID;
                    }
                }
            }

            return true;
        }

        private static ProjectDataSet ReadProjectDataSet(Guid projectUid)
        {
            const int maxAttempts = 7;
            var i = maxAttempts;
            while (i-- > 0)
            {
                try
                {
                    var dsProject = PJContext.Current.PSI.ProjectWebService.ReadProjectEntities(
                                        projectUid,
                                        (int)(ProjectEntityType.Project | ProjectEntityType.ProjectCustomFields | ProjectEntityType.Task),
                                        DATA_STORE);
                    if (dsProject != null && dsProject.Project.Rows.Count > 0)
                        return dsProject;
                }
                catch (Exception)
                {
                    Thread.Sleep(1000 / 2);
                }
            }

            throw new Exception(string.Format("Cannot read project by UID: {0}", projectUid));
        }

        private static bool FilterProject(ProjectDataSet dsProject, IEnumerable<FilterItem> filterBy)
        {
            var filterFieldValues = GetFieldValues(dsProject, filterBy.Select(_ => _.FieldInfo));
            var firstFilterItem = filterBy.ElementAt(0);
            var include = TestFilterItem(filterFieldValues, firstFilterItem);

            for (var i = 1; i < filterBy.Count(); i++)
            {
                var test = TestFilterItem(filterFieldValues, filterBy.ElementAt(i));
                var op = filterBy.ElementAt(i - 1).Operator;

                include = op.Equals("and", StringComparison.InvariantCultureIgnoreCase)
                              ? include && test
                              : include || test;
            }

            return include;
        }

        private static bool TestFilterItem(Dictionary<Guid, object> fieldValues, FilterItem filterItem)
        {
            if (fieldValues.ContainsKey(filterItem.FieldUid))
            {
                var fieldvalue = fieldValues[filterItem.FieldUid];
                if (!(fieldvalue is string) && (fieldvalue is IEnumerable))
                {
                    return fieldValues.Cast<object>().Any(value => IndicatorHelper.TestValue(value, filterItem.Test, filterItem.Value));
                }
                else
                {
                    return IndicatorHelper.TestValue(fieldValues[filterItem.FieldUid], filterItem.Test, filterItem.Value);
                }
            }
            return false;
        }

        private static Dictionary<Guid, object> GetFieldValues(ProjectDataSet dsProject, IEnumerable<PSFieldInfo> fields)
        {
            var fieldsValues = new Dictionary<Guid, object>();
            var lookupValues = new Dictionary<Guid, Dictionary<Guid, object>>();
            //custom fields
            foreach (ProjectDataSet.ProjectCustomFieldsRow cfRow in dsProject.ProjectCustomFields)
            {
                Guid mdPropUid = cfRow.MD_PROP_UID;
                var fieldInfo = fields.FirstOrDefault(_ => _.Uid == mdPropUid);
                if (fieldInfo != null)
                {
                    var customFieldRowData = GetCustomFieldRowData(cfRow, fieldInfo);

                    if (!fieldInfo.LookupTableUid.HasValue)
                    {
                        fieldsValues[fieldInfo.Uid] = customFieldRowData;
                    }
                    else
                    {
                        if (!lookupValues.ContainsKey(fieldInfo.LookupTableUid.Value))
                        {
                            Dictionary<Guid, object> lookupItems = null;
                            SPSecurity.RunWithElevatedPrivileges(() => lookupItems = new LookupTablesService().GetLookupItems(fieldInfo));
                            lookupValues[fieldInfo.LookupTableUid.Value] = lookupItems;
                        }

                        var lookupTableValue = lookupValues[fieldInfo.LookupTableUid.Value][(Guid)customFieldRowData];

                        if (fieldInfo.IsMultiValue)
                        {
                            if (!fieldsValues.ContainsKey(fieldInfo.Uid))
                            {
                                fieldsValues[fieldInfo.Uid] = new List<object>();
                            }

                            ((List<object>)fieldsValues[fieldInfo.Uid]).Add(lookupTableValue);
                        }
                        else
                        {
                            fieldsValues[fieldInfo.Uid] = lookupTableValue;
                        }
                    }
                }
            }

            //native fields
            var projectRow = (ProjectDataSet.ProjectRow)dsProject.Project.Rows[0];
            var taskRow = dsProject.Task.Rows
                .Cast<ProjectDataSet.TaskRow>()
                .First(_ => _.PROJ_UID == projectRow.PROJ_UID && !_.IsTASK_IS_SUMMARYNull() && _.TASK_IS_SUMMARY);
            foreach (var fieldInfo in fields)
            {
                var columnName = CalculateColumnName(fieldInfo);
                if (dsProject.Project.Columns.Contains(columnName)
                    && projectRow[columnName] != DBNull.Value)
                {
                    fieldsValues[fieldInfo.Uid] = projectRow[columnName];
                }
                else if (dsProject.Task.Columns.Contains(columnName))
                {
                    fieldsValues[fieldInfo.Uid] = taskRow[columnName];
                }
            }
            return fieldsValues;
        }

        private static string CalculateColumnName(PSFieldInfo fieldInfo)
        {
            return string.IsNullOrEmpty(fieldInfo.IntrinsicName)
                ? fieldInfo.Uid.ToString()
                : fieldInfo.IntrinsicName;
        }

        private static bool IsCheckedOutByOtherUser(ProjectDataSet.ProjectRow projectRow)
        {
            return !projectRow.IsPROJ_CHECKOUTBYNull() &&
                   projectRow.PROJ_CHECKOUTBY != PJContext.Current.PSI.ResourceWebService.GetCurrentUserUid();

        }

        private static bool TryMakeProjectEditable(ProjectDataSet.ProjectRow projectRow)
        {
            //check if project is checked in and try to check it out
            if (projectRow.IsPROJ_CHECKOUTBYNull())
            {
                //check out project
                try
                {
                    PJContext.Current.PSI.ProjectWebService.CheckOutProject(
                        projectRow.PROJ_UID,
                        ProjectDetailPages.PDP_SESSION_GUID,
                        string.Empty);

                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }

            //for now sessions are not taken into account
            return projectRow.PROJ_CHECKOUTBY == PJContext.Current.UserGuid;
        }

        private static object GetCustomFieldRowData(ProjectDataSet.ProjectCustomFieldsRow cfRow, PSFieldInfo fieldInfo)
        {
            if (fieldInfo.LookupTableUid.HasValue)
                return new Uid(cfRow.CODE_VALUE);

            switch ((PSDataType)cfRow.FIELD_TYPE_ENUM)
            {
                case PSDataType.GUID:
                    return (cfRow.IsCODE_VALUENull()) ? null : (Guid?)cfRow.CODE_VALUE;
                case PSDataType.STRING:
                    return (cfRow.IsTEXT_VALUENull()) ? null : cfRow.TEXT_VALUE;
                case PSDataType.COST:
                    return (cfRow.IsNUM_VALUENull()) ? null : ((decimal?)cfRow.NUM_VALUE) / 100;
                case PSDataType.NUMBER:
                    return (cfRow.IsNUM_VALUENull()) ? null : (decimal?)cfRow.NUM_VALUE;
                case PSDataType.DATE:
                    return (cfRow.IsDATE_VALUENull()) ? null : (DateTime?)cfRow.DATE_VALUE;
                case PSDataType.YESNO:
                    return (cfRow.IsFLAG_VALUENull()) ? null : (bool?)cfRow.FLAG_VALUE;
                case PSDataType.DURATION:
                    return (cfRow.IsDUR_VALUENull()) ? null : (TimeSpan?)TimeSpan.FromSeconds(cfRow.DUR_VALUE * 6 * WORK_TIME_BASIS);
                default:
                    return null;
            }
        }

        private static readonly Regex _durationRegex = new Regex("(\\d+(\\.\\d*)?)(d|h)?");

        private static void SetCustomFieldRowValue(ProjectDataSet.ProjectCustomFieldsRow cfRow, PSFieldInfo fieldInfo, object data)
        {
            if (data == null)
                return;

            var dataType = fieldInfo.LookupTableUid.HasValue ? PSDataType.GUID : fieldInfo.DataType;

            switch (dataType)
            {
                case PSDataType.GUID:
                    cfRow.CODE_VALUE = (Guid)data;
                    break;
                case PSDataType.STRING:
                    cfRow.TEXT_VALUE = (string)data;
                    break;
                case PSDataType.COST:
                    cfRow.NUM_VALUE = Convert.ToDecimal(data) * 100;
                    break;
                case PSDataType.NUMBER:
                    cfRow.NUM_VALUE = Convert.ToDecimal(data);
                    break;
                case PSDataType.DATE:
                    DateTime date;
                    if (DateTime.TryParse(data.ToString(), out date))
                    {
                        cfRow.DATE_VALUE = date;
                    }
                    break;
                case PSDataType.YESNO:
                    cfRow.FLAG_VALUE = Convert.ToBoolean(data);
                    break;
                case PSDataType.DURATION:
                    var strDuration = (string)data;
                    var match = _durationRegex.Match(strDuration);
                    if (match == null || !match.Success)
                    {
                        throw new Exception(string.Format("Cannot set duration value \"{0}\" to custom field \"{1}\"", strDuration, fieldInfo.Name));
                    }

                    var duration = match.Groups.Count > 3 &&
                                   match.Groups[3].Value.Equals("h", StringComparison.InvariantCultureIgnoreCase)
                                       ? TimeSpan.FromHours(Convert.ToDouble(match.Groups[1].Value))
                                       : TimeSpan.FromDays(Convert.ToDouble(match.Groups[1].Value) / WORK_TIME_BASIS);

                    cfRow.DUR_VALUE = (int)(duration.TotalSeconds / 6); //duration is stored as 6 second interval
                    break;
                default:
                    throw new NotSupportedException(string.Format("Unsupported data type: {0}", data.GetType()));
            }
        }

        private static Type GetCustomFieldDataType(PSFieldInfo fieldInfo)
        {
            if (fieldInfo.LookupTableUid.HasValue)
                return fieldInfo.IsMultiValue ? typeof(List<Uid>) : typeof(Uid);

            switch (fieldInfo.DataType)
            {
                case PSDataType.GUID:
                    return typeof(Guid);                
                case PSDataType.STRING:
                    return typeof(string);
                case PSDataType.COST:
                    return typeof(decimal);
                case PSDataType.DOUBLE:
                case PSDataType.WORK:
                case PSDataType.PERCENT:
                case PSDataType.NUMBER:
                    return typeof(decimal);
                case PSDataType.FINISHDATE:
                case PSDataType.DATE:
                    return typeof(DateTime);
                case PSDataType.YESNO:
                    return typeof(bool);
                case PSDataType.DURATION:
                    return typeof(TimeSpan);
                default:
                    return typeof (string);
            }
        }

        internal Dictionary<Guid, object> Update(Dictionary<Guid, Dictionary<string, object>> changes)
        {
            IEnumerable<PSFieldInfo> projectFields = null;
            SPSecurity.RunWithElevatedPrivileges(() => projectFields = new FieldsService().GetProjectFields());                       

            //return the dictionary with projectUid as key and updateJobUid/error message as value
            return changes.ToList()
                .ToDictionary(_ => _.Key,
                              _ => UpdateProject(_.Key, changes[_.Key], projectFields));
        }

        private static object UpdateProject(Guid projectUid, Dictionary<string, object> projectChanges, IEnumerable<PSFieldInfo> projectFields)
        {
            try
            {
                var projectWebService = PJContext.Current.PSI.ProjectWebService;
                using (var dsProject = ReadProjectDataSet(projectUid))
                {
                    foreach (var fieldName in projectChanges.Keys)
                    {
                        var data = ((Dictionary<string, object>)projectChanges[fieldName])["data"];

                        var mdPropUid = Guid.Empty;
                        mdPropUid.TryParse(fieldName, out mdPropUid);

                        if (mdPropUid == Guid.Empty)
                        {
                            //save intrinsic field
                            var projectRow = dsProject.Project[0];

                            if(fieldName == dsProject.Project.ENTERPRISE_PROJECT_TYPE_NAMEColumn.ColumnName)
                            {
                                PJContext.Current.PSI.WorkflowWebService.UpdateProjectWorkflow(projectUid, new Guid(data.ToString()));
                            }
                            else if (dsProject.Project.Columns.Contains(fieldName))
                            {
                                projectRow[fieldName] = data;
                            }
                            else
                            {
                                SetSpecificIntrinsicField(projectRow, fieldName, data);
                            }
                        }
                        else
                        {
                            //save custom fields
                            var fieldInfo = projectFields.First(_ => _.Uid == mdPropUid);

                            MapCustomFieldToDataSet(projectUid, dsProject, fieldInfo, data);
                        }
                    }

                    var jobUid = Guid.NewGuid();
                    projectWebService.QueueUpdateProject(
                        jobUid,
                        ProjectDetailPages.PDP_SESSION_GUID,
                        dsProject,
                        false);
                    projectWebService.QueuePublishSummary(Guid.NewGuid(), projectUid);
                    projectWebService.QueueCheckInProject(
                        Guid.NewGuid(),
                        projectUid,
                        true,
                        ProjectDetailPages.PDP_SESSION_GUID,
                        string.Empty);
                    //throw new Exception("My Error text");
                    return new { jobUid };
                }
            }
            catch (Exception e)
            {
                return new { error = e.Message };
            }
        }

        private static void SetSpecificIntrinsicField(ProjectDataSet.ProjectRow projectRow, string fieldName, object data)
        {
            if ("{3317C796-5FA1-4231-9212-A4C90A2CE05F}".IndexOf(fieldName, StringComparison.InvariantCultureIgnoreCase) > -1 ||
                "TASK_START_DATE".Equals(fieldName))
            {
                if(data == null)
                    throw new Exception("Start Date field is required.");
                
                DateTime startDate;
                if(!DateTime.TryParse(data.ToString(), out startDate))
                    throw new Exception(string.Format("Invalid Project Start Date {0}", startDate));

                if ((startDate < ValidationConst.MinProjectDate) || (startDate > ValidationConst.MaxProjectDate))
                {
                    throw new Exception(string.Format("Invalid Project Start Date {0}", startDate));
                }

                projectRow.PROJ_INFO_START_DATE = startDate;
            }
            else if("RES_NAME".Equals(fieldName))
            {
                if (data == null)
                    throw new Exception("Project Owner field is required.");

                projectRow.ProjectOwnerID = new Guid(data.ToString());
            }
        }

        private static void MapCustomFieldToDataSet(Guid projectUid, ProjectDataSet dsProject, PSFieldInfo fieldInfo, object data)
        {
            var fieldRelatedRows = dsProject.ProjectCustomFields.Rows
                .Cast<ProjectDataSet.ProjectCustomFieldsRow>()
                .Where(row => row.PROJ_UID == projectUid && row.MD_PROP_UID == fieldInfo.Uid)
                .ToList();

            var fieldValue = fieldInfo.DataType == PSDataType.YESNO ? ((int)data == -1 ? null : data) : data;

            if (fieldRelatedRows.Count == 1 && !fieldInfo.LookupTableUid.HasValue && fieldValue != null)
            {
                SetCustomFieldRowValue(fieldRelatedRows[0], fieldInfo, fieldValue);
            }
            else
            {
                List<object> rowValues;
                if (fieldValue != null)
                {
                    if (!(fieldValue is string) && (fieldValue is IEnumerable))
                    {
                        rowValues = new List<object>();
                        foreach (var value in (IEnumerable)fieldValue)
                        {
                            var codeValue = Guid.Empty;
                            codeValue.TryParse(value.ToString(), out codeValue);
                            if (codeValue != Guid.Empty)
                            {
                                rowValues.Add(codeValue);
                            }
                        }
                    }
                    else
                    {
                        if (fieldInfo.LookupTableUid.HasValue)
                        {
                            rowValues = new List<object>();
                            var codeValue = Guid.Empty;
                            codeValue.TryParse(fieldValue.ToString(), out codeValue);
                            if (codeValue != Guid.Empty)
                            {
                                rowValues.Add(codeValue);
                            }
                        }
                        else
                        {
                            rowValues = new List<object> { fieldValue };
                        }
                    }
                }
                else
                {
                    rowValues = new List<object>();
                }

                foreach (var rowValue in rowValues)
                {
                    var row = fieldRelatedRows
                        .FirstOrDefault(r => !r.IsCODE_VALUENull() && r.CODE_VALUE == (Guid)rowValue);

                    if (row == null)
                    {
                        //create new row
                        row = dsProject.ProjectCustomFields.NewProjectCustomFieldsRow();
                        row.MD_PROP_UID = fieldInfo.Uid;
                        row.CUSTOM_FIELD_UID = Guid.NewGuid();
                        row.PROJ_UID = projectUid;
                        row.FIELD_TYPE_ENUM = (byte)fieldInfo.DataType;

                        SetCustomFieldRowValue(
                            row,
                            fieldInfo,
                            rowValue);

                        dsProject.ProjectCustomFields.Rows.Add(row);
                    }
                    else
                    {
                        fieldRelatedRows.Remove(row);
                    }
                }
                //remove unused rows
                foreach (var row in fieldRelatedRows)
                    row.Delete();
            }
        }
    }
}
