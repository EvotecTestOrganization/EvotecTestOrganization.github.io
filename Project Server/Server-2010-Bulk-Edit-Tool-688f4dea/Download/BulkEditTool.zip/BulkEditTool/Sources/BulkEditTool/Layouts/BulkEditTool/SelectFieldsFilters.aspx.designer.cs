﻿namespace DemandManagement.BulkEditTool.Layouts.BulkEditTool
{
    public partial class SelectFieldsFilters
    {
        protected global::Microsoft.Office.Project.PWA.CommonControls.PageProperty idPageProperty;
        protected global::Microsoft.Office.Project.PWA.CommonControls.ItemSwapper itemSwapperFields;
    }
}
