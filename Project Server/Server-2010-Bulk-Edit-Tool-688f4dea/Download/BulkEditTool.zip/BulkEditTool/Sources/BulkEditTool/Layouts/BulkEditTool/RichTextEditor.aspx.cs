﻿using System;
using System.Web.UI.WebControls;
using Microsoft.Office.Project.PWA;
using Microsoft.SharePoint.Publishing.WebControls;
using Microsoft.SharePoint.WebControls;

namespace DemandManagement.BulkEditTool.Layouts.BulkEditTool
{
    public partial class RichTextEditor : PJWebPage
    {
        private bool? _isPlainText;

        protected bool IsPlainText
        {
            get
            {
                if (!_isPlainText.HasValue)
                {
                    _isPlainText = "true".Equals(Page.Request.QueryString["IsPlainText"], StringComparison.InvariantCultureIgnoreCase);
                }

                return _isPlainText.Value;
            }
        }

        public override void PJWebPage_OnLoad(EventArgs e)
        {
            base.PJWebPage_OnLoad(e);

            if (!IsPlainText)
            {
                InitRibbon();
            }

            idPageProperty.Title = IsPlainText
                                       ? GlobalResources.BulkEditTool.MULTILINE_TEXT_EDITOR_PAGE_TITLE
                                       : GlobalResources.BulkEditTool.RICH_TEXT_EDITOR_PAGE_TITLE;
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            if (!IsPlainText)
            {
                var htmlEditor = new HtmlEditor
                                            {
                                                ID = "htmlEditor",
                                                Field = new RichHtmlField { ControlMode = SPControlMode.Edit },
                                                UseIntranetMode = true,
                                                Html = "&nbsp;",
                                                CssClass = "html-editor",                                                
                                            };
                editorContainer.Controls.Add(htmlEditor);
            }
            else
            {
                var plainTextEditor = new TextBox
                                          {
                                              ID = "plainTextEditor",
                                              TextMode = TextBoxMode.MultiLine,
                                              CssClass = "plain-text-editor",
                                          };
                editorContainer.Controls.Add(plainTextEditor);
            }
        }

        private void InitRibbon()
        {
            var ribbon = SPRibbon.GetCurrent(this);
            ribbon.Minimized = false;
            ribbon.CommandUIVisible = true;

            //const string tabId = "Ribbon.Read";
            //if (!ribbon.IsTabAvailable(tabId))
            //    ribbon.MakeTabAvailable(tabId);
            //ribbon.InitialTabId = tabId;
        }
    }
}
