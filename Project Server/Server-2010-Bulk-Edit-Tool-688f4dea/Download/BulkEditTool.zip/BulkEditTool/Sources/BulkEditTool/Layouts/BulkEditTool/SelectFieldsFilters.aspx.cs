﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Web.UI.WebControls;
using DemandManagement.BulkEditTool.DTO;
using DemandManagement.BulkEditTool.Services;
using Microsoft.Office.Project.PWA;
using Microsoft.SharePoint;

namespace DemandManagement.BulkEditTool.Layouts.BulkEditTool
{
    public partial class SelectFieldsFilters : PJWebPage
    {
        protected DropDownList ddlFields;

        public override void PJWebPage_OnLoad(EventArgs e)
        {
            base.PJWebPage_OnLoad(e);

            if (!ServicePointManager.ServerCertificateValidationCallback.GetInvocationList().Contains(new RemoteCertificateValidationCallback(Utils.ServerCertificateValidation)))
                ServicePointManager.ServerCertificateValidationCallback += Utils.ServerCertificateValidation;

            if(!IsPostBack)
            {
                IEnumerable<PSFieldInfo> fields = null;

                SPSecurity.RunWithElevatedPrivileges(() => fields = new FieldsService().GetProjectFields());

                BindGridFields(fields);

                BindFilterFields(fields);
            }
        }

        public override bool CheckPagePermission()
        {
            return true;
        }

        private readonly Dictionary<Guid, bool> _betaFields = new Dictionary<Guid, bool>
            {
                { new Guid("8452f6a8-bc6c-4367-8836-a6ae55bbdda4"), true }, //Project Name - text
                { new Guid("3317c796-5fa1-4231-9212-a4c90a2ce05f"), false }, //Start - date
                { new Guid("39bbff4f-b576-4e78-a3f2-a1c03f9c9ac9"), false }, //Finish - date
                

                /*
                { new Guid("837aafa9-fa1a-49c0-8a08-6b007865991b"), false }, //Description - multiline text
                { new Guid("512da80a-1fe3-4a5c-a4e6-e53757e11329"), false }, //Fiscal Year - single line text
                { new Guid("9ee3883f-4f3f-47ad-8eba-b21947e51c97"), false }, //Executive Summary Description Overview - rich text
                { new Guid("0000bfd3-64ea-43cc-aa00-e1289615a7a1"), false }, //Enterprise Project Type Name - 
                { new Guid("3d441692-c3a5-4016-8c54-fd2b82568ec0"), false }, //Test Lookup Field - multivalue lookup
                                               
                { new Guid("509c6ac3-9558-43de-8824-810fe4229c67"), false }, //Test Duration Field - duration
                
                { new Guid("bfe9e3c0-6c7a-43d6-9623-49f69dc5c0ec"), false }, //Project I/O - number
                { new Guid("14bd8975-fd8c-47e9-9c60-21ac58a0facc"), false }, //Planned Start Date - date
                { new Guid("759c6ad4-aaa3-4b50-9522-548229854cd8"), false  }, //Project Owner
                
                /*
                { new Guid("7334e2cd-60e5-40a0-9419-0073437bea5f"), false }, //Sample Compliance Proposal - flag
                { new Guid("203c43d7-ab22-41a0-9b32-2d42fd152ec6"), false }, //Total Soft Savings - cost
                { new Guid("a217875c-c9b2-4bc8-a32e-d46c0d300705"), false }, //Business Owner - text
                
                */
            };


        private void BindGridFields(IEnumerable<PSFieldInfo> fields)
        {
            itemSwapperFields.LblAlphaList.Text = PJUtility.GetLocalizedString("LIBRARY_FIELD_PICKER_FIELDS", new object[0]);
            itemSwapperFields.LblBetaList.Text = PJUtility.GetLocalizedString("LIBRARY_FIELD_PICKER_SELECTED_FIELDS", new object[0]);
            itemSwapperFields.ShowRemoveAllButton = false;
            itemSwapperFields.BetaListMaxItems = 255;

            //prepare data tables to use as data sources
            var dsAlpha = new DataTable();            
            dsAlpha.Columns.Add(new DataColumn("Value", typeof(string)));
            dsAlpha.Columns.Add(new DataColumn("Text", typeof(string)));
            dsAlpha.Columns.Add(new DataColumn("Fixed", typeof(bool)));
            dsAlpha.PrimaryKey = new[] { dsAlpha.Columns[0] };
            var dsBeta = dsAlpha.Clone();

            foreach (var fieldInfo in fields)
            {
                if (fieldInfo.IsCustomField != 2)
                {
                    if(!_betaFields.ContainsKey(fieldInfo.Uid))
                        dsAlpha.Rows.Add(fieldInfo.Uid.ToString(), fieldInfo.Name, false);
                }
            }

            foreach (var betaField in _betaFields)
            {
                dsBeta.Rows.Add(betaField.Key.ToString(), fields.First(_ => _.Uid == betaField.Key).Name, betaField.Value);
            }

            //set data sources
            itemSwapperFields.AlphaSelect.DataSource = dsAlpha;
            itemSwapperFields.BetaSelect.DataSource = dsBeta;
        }

        private void BindFilterFields(IEnumerable<PSFieldInfo> fields)
        {
            ddlFields.Items.Add(string.Empty);

            foreach (var field in fields)
            {
                ddlFields.Items.Add(new ListItem(field.Name, field.Uid.ToString()));
            }
        }
    }
}
