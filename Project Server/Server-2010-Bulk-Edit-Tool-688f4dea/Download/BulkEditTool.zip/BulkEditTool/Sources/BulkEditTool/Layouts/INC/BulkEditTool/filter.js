﻿(function ($) {
    $.extend($.fn, {
        filter: function (filterBy, messages) {

            var $this = this;
            var $body = $this.find('tbody');

            if (filterBy && filterBy.length > 0) {
                var row = $body.find('tr:first');
                fillRow(row, filterBy[0]);
                for (var i = 1; i < filterBy.length; i++) {
                    var newRow = row.clone();
                    fillRow(newRow, filterBy[i]);
                    $body.append(newRow);
                }
            }

            $body.find('tr select.filterOperator').live('change', function () {
                var currentRow = $(this).parents('tr:first');
                if (this.options.selectedIndex > 0 && currentRow.next().length == 0) {
                    var newRow = currentRow.clone();
                    fillRow(newRow, { FieldUid: '', Test: '', Value: '', Operator: 'Nop' }, messages.InvalidFieldName);
                    $body.append(newRow);
                }
            });

            $body.find('tr select, tr input').live('blur', function () {
                var currentRow = $(this).parents('tr:first');
                validateRow(currentRow);
            });

            $body.find('tr button.filterDelete').live('click', function (event) {
                var currentRow = $(this).parents('tr:first');
                if (currentRow.prev().length > 0) {
                    if (currentRow.next().length == 0) {
                        var prevRow = currentRow.prev();
                        prevRow.find('.filterOperator')[0].options[0].selected = true;

                        validateRow(prevRow);
                    }

                    currentRow.remove();
                }

                event.preventDefault();
            });

            $this.getFilter = function () {
                if ($body.find('img[src*="new.gif"]').length == 1)
                    return [];

                var filter = [];

                $body.find('tr').each(function (index, row) {
                    var $row = $(row);
                    var filterItem = getFilterItem($row);
                    filter.push(filterItem);
                });

                return filter;
            };

            $this.isValid = function () {
                return ($body.find('img[src*="redx.gif"]').length == 0);
            }

            return $this;

            function validateRow(row) {
                var isFirstRow = (row.prev().length == 0);
                var isLastRow = (row.next().length == 0);

                var filterItem = getFilterItem(row);

                var imgIsValid = row.find('.filterIsValid');

                if (!filterItem.FieldUid && !filterItem.Test && filterItem.Operator == 'Nop' && isFirstRow && isLastRow) {
                    imgIsValid.attr('src', '../1033/images/new.gif').attr('title', messages.New);
                }
                else if (!filterItem.FieldUid) {
                    imgIsValid.attr('src', '../inc/pwa/images/redx.gif').attr('title', messages.InvalidFieldName);
                }
                else if (!filterItem.Test) {
                    imgIsValid.attr('src', '../inc/pwa/images/redx.gif').attr('title', messages.InvalidTest);
                }
                else if (filterItem.Operator == 'Nop' && !isLastRow) {
                    imgIsValid.attr('src', '../inc/pwa/images/redx.gif').attr('title', messages.InvalidOperator);
                }
                else {
                    imgIsValid.attr('src', '../inc/pwa/images/greencheck.gif').attr('title', messages.Valid);
                }
            }

            function fillRow(row, filterItem, errorMessage) {
                row.find('.filterFields option[value="' + filterItem.FieldUid + '"]')[0].selected = true;
                row.find('.filterTest option[value="' + filterItem.Test + '"]')[0].selected = true;
                row.find('.filterOperator option[value="' + filterItem.Operator + '"]')[0].selected = true;
                row.find('.filterValue').val(filterItem.Value);

                if (errorMessage)
                    row.find('.filterIsValid').attr('src', '../inc/pwa/images/redx.gif').attr('title', errorMessage);
                else
                    row.find('.filterIsValid').attr('src', '../inc/pwa/images/greencheck.gif').attr('title', messages.Valid);
            }

            function getFilterItem(row) {
                var filterItem = {};
                filterItem.FieldUid = row.find('.filterFields option:selected').val();
                filterItem.Test = row.find('.filterTest option:selected').val();
                filterItem.Value = row.find('.filterValue').val();
                filterItem.Operator = row.find('.filterOperator option:selected').val();
                return filterItem;
            }
        }
    });
})(jQuery);