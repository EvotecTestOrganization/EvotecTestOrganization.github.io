﻿namespace DemandManagement.BulkEditTool.Layouts.BulkEditTool
{
    public partial class RichTextEditor
    {
        protected global::Microsoft.Office.Project.PWA.CommonControls.PageProperty idPageProperty;
        protected global::System.Web.UI.HtmlControls.HtmlGenericControl editorContainer;
    }
}
