﻿/// <reference name="MicrosoftAjax.debug.js"/>
/// <reference path="~/_layouts/SP.core.debug.js"/>
/// <reference path="~/_layouts/SP.core.js"/>
/// <reference path="~/_layouts/SP.debug.js"/>
/// <reference path="~/_layouts/SP.js"/>
/// <reference path="~/_layouts/JSGrid.js" />
/// <reference path="~/_layouts/inc/pwa/library/shell.debug.js" />
/// <reference path="~/_layouts/SP.Ribbon.debug.js" />
/// <reference path="~/_layouts/SP.Ribbon.js" />
/// <reference path="~/_layouts/inc/pwa/library/CustomFieldWidget.js" />
/// <reference path="~/_layouts/inc/pwa/library/ProjectFramework.js" />

Type.registerNamespace("GridManager");
GridManager = function () {
    var CMD_SHOW_PROJECTS = 'ShowProjects';
    var CMD_EDIT_PROJECTS = 'EditProjects';
    var CMD_SAVE_PROJECTS = 'SaveProjects';
    var _jsGridControl;
    var _GIDisplayControl;
    var _GIPropType;
    var _RichTextDisplayControl;
    var _RichTextEditControl;
    var _RichTextPropType;
    var _ProjectOwnerDisplayControl;
    var _ProjectOwnerEditControl;
    var _ProjectOwnerPropType;
    var _initialData;
    var _props;
    var _jsGridParams;
    var _additionalParams;
    var _dataSource;
    var _selectedFields = [];
    var _selectedProjects = [];
    var _changesToSave;
    var _filterBy;
    var _currentCommand;
    var _orderByColumnName;
    var _isDescending;
    var _isRibbonDisabled = false;
    var _queueCheckInterval = 2000;
    var _gridData;

    this.Init = function (jsGridControl, initialData, props) {
        _jsGridControl = jsGridControl;
        _initialData = initialData;
        _props = props;

        _jsGridControl.AttachEvent(SP.JsGrid.EventType.OnCellEditCompleted, OnCellEditCompleted);
        _jsGridControl.AttachEvent(SP.JsGrid.EventType.OnRecordChecked, OnRecordChecked);
        _jsGridControl.SetDelegate(SP.JsGrid.DelegateType.GetRecordEditMode, GetRecordEditMode);
        _jsGridControl.SetDelegate(SP.JsGrid.DelegateType.Sort, HandleSort);

        SP.JsGrid.PropertyType.Utils.RegisterWidgetControl('RichTextWidget', function (context) { return new RichTextWidget(context); })

        //graphical indicator display control
        _GIDisplayControl = new GIDisplayControl();
        SP.JsGrid.PropertyType.Utils.RegisterDisplayControl(_GIDisplayControl.Id, _GIDisplayControl, []);

        _GIPropType = new GIPropType();
        SP.JsGrid.PropertyType.RegisterNewCustomPropType(_GIPropType, _GIDisplayControl.Id, _GIDisplayControl.Id);

        //multiline text display control
        _RichTextDisplayControl = new RichTextDisplayControl();
        SP.JsGrid.PropertyType.Utils.RegisterDisplayControl(_RichTextDisplayControl.Id, _RichTextDisplayControl, []);

        SP.JsGrid.PropertyType.Utils.RegisterEditControl('RichTextEditControl', function (gridContext) { return (this._RichTextEditControl = new RichTextEditControl(gridContext)); }, []);

        _RichTextPropType = new RichTextPropType();
        SP.JsGrid.PropertyType.RegisterNewCustomPropType(_RichTextPropType, _RichTextDisplayControl.Id, 'RichTextEditControl', ['RichTextWidget']);

        //CustomJSNumber
        RegisterCustomNumberPropType();

        //CustomJSDateTime
        RegisterCustomDateTimePropType();

        //CustomString
        RegisterCustomStringPropType();

        //project owner display control
        _ProjectOwnerDisplayControl = new ProjectOwnerDisplayControl();
        SP.JsGrid.PropertyType.Utils.RegisterDisplayControl(_ProjectOwnerDisplayControl.Id, _ProjectOwnerDisplayControl, []);

        SP.JsGrid.PropertyType.Utils.RegisterEditControl('ProjectOwnerEditControl', function (gridContext) { return (this._ProjectOwnerEditControl = new ProjectOwnerEditControl(gridContext)); }, []);

        _ProjectOwnerPropType = new ProjectOwnerPropType();
        SP.JsGrid.PropertyType.RegisterNewCustomPropType(_ProjectOwnerPropType, _ProjectOwnerDisplayControl.Id, 'ProjectOwnerEditControl');

        PJ.RemoteTextConv.Init();

        _jsGridControl.HideInitialLoadingBanner();
        this.SelectFieldsFilters();

        window.onbeforeunload = function () {
            if (GM.IsSaveProjectsEnabled()) {
                return "There are changes on this page that haven't been saved. If you continue, the changes will be lost."
            }
        }
    }

    function HandleSort(newSortedCols) {
        _orderByColumnName = newSortedCols[0].columnName;
        _isDescending = newSortedCols[0].isDescending;

        BindJSGrid(_currentCommand);
    }

    this.SelectFieldsFilters = function () {
        var options = {
            allowautoresize: false,
            allowmaximize: false,
            width: 800,
            height: 300
        };

        var oArguments = {
            selectedFields: _selectedFields,
            filterBy: _filterBy
        };

        PJShowWSSModalDialog(
            String.format('{0}/_layouts/BulkEditTool/SelectFieldsFilters.aspx', _props.pwa),
            options,
            fnCustomFilterCallback,
            oArguments);
    }
    function fnCustomFilterCallback(oDialogResult, oRet) {
        ULSjSZ: ;
        if (oDialogResult) {
            _selectedFields = cloneArray(oRet.selectedFields);
            _filterBy = cloneArray(oRet.filterBy);
            _orderByColumnName = 'PROJ_NAME';
            _isDescending = false;

            _selectedProjects = [];

            ClearAllErrors();

            BindJSGrid(CMD_SHOW_PROJECTS);
        }
    }
    function cloneArray(arr) {
        var o = new Array();
        for (i = 0; i < arr.length; i++) {
            o.push(arr[i]);
        }
        return o;
    }
    function BindJSGrid(command) {
        _currentCommand = command;
        _jsGridControl.Disable();
        RefreshRibbon(false);

        var args = Sys.Serialization.JavaScriptSerializer.serialize({
            Command: command,
            SelectedFields: _selectedFields,
            SelectedProjects: _selectedProjects,
            FilterBy: _filterBy,
            Changes: _changesToSave,
            OrderByColumnName: _orderByColumnName,
            IsDescending: _isDescending
        });

        eval(_props.callbackScript);
    }
    this.DisplayProjectsData = function (data) {
        //clear grid
        if (_jsGridControl.IsInitialized()) {
            _jsGridControl.ClearChanges();
            _jsGridControl.ClearTableView();
        }

        //show data in grid
        if (data && data != '') {

            var responseData = Sys.Serialization.JavaScriptSerializer.deserialize(data);
            _gridData = SP.JsGrid.Deserializer.DeserializeFromJson(responseData.gridJson);
            if (!_dataSource)
                _dataSource = new SP.JsGrid.StaticDataSource(_gridData);
            else
                _dataSource.LoadSerializedData(_gridData);

            _jsGridParams = _dataSource.InitJsGridParams();

            _jsGridParams.styleManager.RegisterCellStyle('CheckedOutByOtherUser', SP.JsGrid.Style.CreateStyle(SP.JsGrid.Style.Type.Cell, { backgroundColor: '#eeeeee' }));

            _additionalParams = _dataSource.GetAdditionalParams();

            _jsGridParams.tableViewParams.bEditingEnabled = _currentCommand == CMD_EDIT_PROJECTS;
            _jsGridParams.tableViewParams.bRecordIndicatorCheckboxesEnabled = true;

            _jsGridParams.tableViewParams.bSortableColumns = _currentCommand != CMD_EDIT_PROJECTS;

            _jsGridParams.bEnableDiffTracking = true;

            PJ.InitProjectFrameworkForGrid(_jsGridControl, _jsGridParams.tableViewParams, _additionalParams, true, false, _props.pwa);

            if (!_jsGridControl.IsInitialized()) {
                _jsGridControl.Init(_jsGridParams);
            }
            else {
                _jsGridControl.SetTableView(_jsGridParams.tableViewParams);
            }

            //row selection should be disabled for projects checked out by other users
            var allRecords = GetAllRecords();
            for (var i in allRecords) {
                var record = allRecords[i];
                if (!record.GetDataValue('IsProjectEditable') || _currentCommand == CMD_EDIT_PROJECTS) {
                    _jsGridControl.GetCheckSelectionManager().DisableRecordCheckbox(record.recordKey);
                }

                if (!record.GetDataValue('IsProjectEditable')) {
                    _jsGridControl.AddRowHeaderState(
                        record.recordKey,
                        new SP.JsGrid.RowHeaderState(
                            SP.JsGrid.RowHeaderStyleId.Conflict,
                            new SP.JsGrid.Image('/_layouts/Images/info16by16.gif', false),
                            SP.JsGrid.RowHeaderStatePriorities.Dirty,
                            'Project is checked out by other user.')
                    );
                }
                else {
                    _jsGridControl.RemoveRowHeaderState(record.recordKey, SP.JsGrid.RowHeaderStyleId.Conflict)
                }
            }

            ProcessCommandContext(responseData.commandContext);
        }

        RefreshRibbon(true);
        _jsGridControl.Enable();
    }

    function GetAllRecords() {
        if (_dataSource && _dataSource.tableCache) {
            var ranges = [{ pos: 0, count: _dataSource.tableCache.GetRecordCount()}];
            var allRecords = _dataSource.tableCache.GetRecords(ranges).records[0];
            return allRecords;
        }

        return null;
    }

    function ClearAllErrors() {
        var allRecords = GetAllRecords();
        if (allRecords) {
            for (var i in allRecords) {
                var record = allRecords[i];
                _jsGridControl.ClearAllErrorsOnRow(record.recordKey);
            }
        }
    }

    function ProcessCommandContext(commandContext) {
        if (typeof commandContext == null)
            return;

        if (_currentCommand == CMD_SAVE_PROJECTS || _currentCommand == CMD_SHOW_PROJECTS) {
            _jobsCount = 0;
            for (var projKey in commandContext.updateJobs) {
                if (typeof commandContext.updateJobs[projKey].jobUid !== 'undefined') {
                    _jobsCount++;
                }
            }
            UpdateJobsCountNotification();

            for (var projKey in commandContext.updateJobs) {
                if (typeof commandContext.updateJobs[projKey].jobUid !== 'undefined') {
                    //add row header state 'Updating'
                    _jsGridControl.AddRowHeaderState(
                        projKey,
                        new SP.JsGrid.RowHeaderState(
                            SP.JsGrid.RowHeaderStyleId.Transfer,
                            new SP.JsGrid.Image('/_layouts/Images/jsgridcluster.png', true, 'clip16x16', 'jsgridcluster_transferheader'),
                            SP.JsGrid.RowHeaderStatePriorities.Dirty,
                            _props.resources.PROJECT_IS_QUEUED_FOR_UPDATE));

                    CheckQueue(
                        projKey,
                        commandContext.updateJobs[projKey].jobUid,
                        function (rowKey) { _jsGridControl.RemoveRowHeaderState(rowKey, SP.JsGrid.RowHeaderStyleId.Transfer); },
                        function (rowKey) {
                            _jsGridControl.RemoveRowHeaderState(rowKey, SP.JsGrid.RowHeaderStyleId.Transfer);
                            _jsGridControl.SetRowError(
                                rowKey,
                                _props.resources.PROJECT_UPDATE_JOB_FAILED);
                        });
                }
                else {
                    _jsGridControl.SetRowError(
                        projKey,
                        commandContext.updateJobs[projKey].error);
                }
            }
        }
    }
    var _nid;
    var _jobsCount;
    function UpdateJobsCountNotification() {
        if (_jobsCount == 0) {
            SP.UI.Notify.removeNotification(_nid);
        }
        else if (_jobsCount > 0) {
            var spanId = 'Update_jobs_count';
            var span = document.getElementById(spanId);
            if (span != null) {
                span.innerHTML = _jobsCount;
            }
            else {
                _nid = SP.UI.Notify.addNotification(
                    String.format(
                        _props.resources.UPDATE_JOBS_COUNT_STRING_FORMAT,
                        String.format('<span id="{0}">{1}</span>', spanId, _jobsCount)),
                        true);
            }
        }
    }
    function CheckQueue(projKey, jobUid, fnCompleted, fnFailed) {
        var jobState = CheckQueueJobState(jobUid, _props.pwa);
        if (jobState.state == PJQueueJobState.Failed ||
            jobState.state == PJQueueJobState.Success ||
            jobState.state == PJQueueJobState.FailedNotBlocking ||
            jobState.state == PJQueueJobState.CorrelationBlocked ||
            jobState.state == PJQueueJobState.Cancelled) {
            if (jobState.error <= 0) {
                fnCompleted(projKey);
            }
            else {
                fnFailed(projKey);
            }

            _jobsCount--;
            UpdateJobsCountNotification();

            if (_jobsCount == 0)
                BindJSGrid(CMD_SHOW_PROJECTS);
        }
        else {
            setTimeout(
                function () { CheckQueue(projKey, jobUid, fnCompleted, fnFailed); },
                _queueCheckInterval);
        }
    }
    this.GoToMyQueuedJobs = function () {
        window.open(String.format('{0}/MyJobs.aspx', _props.pwa));
        //window.location.href = String.format('{0}/MyJobs.aspx',_props.pwa);
    }
    this.IsSelectFieldsFiltersEnabled = function () {
        return !_isRibbonDisabled && _currentCommand != CMD_EDIT_PROJECTS;
    }
    this.EditSelectedProjects = function () {
        var getKeys = function (obj) {
            var keys = [];
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    keys.push(key);
                }
            }
            return keys;
        }
        _selectedProjects = getKeys(_jsGridControl.GetCheckSelectionManager().GetCheckedRecordKeys());

        ClearAllErrors();

        BindJSGrid(CMD_EDIT_PROJECTS);
    }
    this.IsEditSelectedProjectsEnabled = function () {
        //check if at least one project selected
        var anyRowsSelected = _jsGridControl.IsInitialized() && _jsGridControl.GetCheckSelectionManager().AnyRecordsChecked();
        return !_isRibbonDisabled && _currentCommand != CMD_EDIT_PROJECTS && anyRowsSelected;
    }
    this.SaveProjects = function () {
        //check data validity
        if (!_jsGridControl.AnyErrors()) {
            var diffTracker = _jsGridControl.GetDiffTracker();
            if (diffTracker.AnyChanges()) {
                _jsGridControl.DisableEditing();
                //perform save
                var diffs = diffTracker.GetUniquePropertyChanges();

                _changesToSave = diffs;
                for (var projectUid in _changesToSave) {
                    for (var customFieldUid in _changesToSave[projectUid]) {
                        if (_dataSource.recordFactory.gridFieldMap[customFieldUid]._propType.ID.indexOf(customFieldUid + '_LT') > 0) {
                            if (!_changesToSave[projectUid][customFieldUid]['data'].length) {
                                _changesToSave[projectUid][customFieldUid]['data'] = SP.JsGrid.GuidManager.LookupGuidForIndex(_changesToSave[projectUid][customFieldUid]['data']);
                            }
                            else {
                                for (var i = 0; i < _changesToSave[projectUid][customFieldUid]['data'].length; i++) {
                                    _changesToSave[projectUid][customFieldUid]['data'][i] = SP.JsGrid.GuidManager.LookupGuidForIndex(_changesToSave[projectUid][customFieldUid]['data'][i]);
                                }
                            }
                        }
                    }
                }

                BindJSGrid(CMD_SAVE_PROJECTS);
            }
            else
                alert(_props.resources.NO_CHANGES_DONE);
        }
    }
    this.IsSaveProjectsEnabled = function () {
        //check if any modifications are provided
        var isDirty = _jsGridControl.IsInitialized() && !_jsGridControl.AnyErrors() && _jsGridControl.GetDiffTracker().AnyChanges();
        return !_isRibbonDisabled && _currentCommand == CMD_EDIT_PROJECTS && isDirty;
    }

    this.CancelEdit = function () {
        _selectedProjects = [];

        _jsGridParams.commandMgr.Undo();

        BindJSGrid(CMD_SHOW_PROJECTS);
    }

    this.IsCancelEnabled = function () {
        return !_isRibbonDisabled && _currentCommand == CMD_EDIT_PROJECTS;
    }

    this.Refresh = function () {
        _selectedProjects = [];

        ClearAllErrors();

        BindJSGrid(CMD_SHOW_PROJECTS);
    }

    this.IsRefreshEnabled = function () {
        return !_isRibbonDisabled && (_currentCommand == CMD_SHOW_PROJECTS || _currentCommand == CMD_SAVE_PROJECTS);
    }

    function OnCellEditCompleted(obj) {
        setTimeout(RefreshRibbon, 500);
    }
    function OnRecordChecked(obj) {
        RefreshRibbon();
    }
    function GetRecordEditMode(record) {
        if (_currentCommand == CMD_EDIT_PROJECTS && !record.GetDataValue('IsProjectEditable')) {
            return SP.JsGrid.EditMode.ReadOnly;
        }
        else {
            return SP.JsGrid.EditMode.ReadWrite;
        }
    }
    function RefreshRibbon(enable) {
        if (typeof enable !== 'undefined')
            _isRibbonDisabled = !enable;

        SP.Ribbon.PageManager.get_instance().get_commandDispatcher().executeCommand(Commands.CommandIds.ApplicationStateChanged, null);
    }

    function RegisterCustomNumberPropType() {
        var basePropType = SP.JsGrid.Internal.Property.GetPropType('JSNumber');
        var customNumberPropType = SP.Internal.JS.object(basePropType);
        customNumberPropType.ID = 'CustomJSNumber';
        customNumberPropType.BeginValidateNormalizeConvert = function (recordKey, fieldKey, newValue, bIsLocalized, fnCallback, fnError) {

            basePropType.BeginValidateNormalizeConvert.apply(this, [recordKey, fieldKey, newValue, bIsLocalized, PostProcess, fnError]);
            function PostProcess(result) {

                result.isValid = newValue == '' || result.isValid;
                result.dataValue = result.normalizedLocValue = newValue == '' ? null : newValue;

                fnCallback(result);
            }
        };
        SP.JsGrid.PropertyType.RegisterNewDerivedCustomPropType(customNumberPropType, 'JSNumber');
    }

    function RegisterCustomDateTimePropType() {
        var basePropType = SP.JsGrid.Internal.Property.GetPropType('JSDateTime');
        var customDateTimePropType = SP.Internal.JS.object(basePropType);
        customDateTimePropType.ID = 'CustomJSDateTime';
        customDateTimePropType.BeginValidateNormalizeConvert = function (recordKey, fieldKey, newValue, bIsLocalized, fnCallback, fnError) {

            basePropType.BeginValidateNormalizeConvert.apply(this, [recordKey, fieldKey, newValue, bIsLocalized, PostProcess, fnError]);
            function PostProcess(result) {

                result.isValid = newValue == '' || result.isValid;
                result.dataValue = result.normalizedLocValue = newValue == '' ? null : newValue;

                fnCallback(result);
            }
        };
        SP.JsGrid.PropertyType.RegisterNewDerivedCustomPropType(customDateTimePropType, 'JSDateTime');
    }

    function RegisterCustomStringPropType() {
        var basePropType = SP.JsGrid.Internal.Property.GetPropType('String');
        var customStringPropType = SP.Internal.JS.object(basePropType);
        customStringPropType.ID = 'CustomString';
        customStringPropType.BeginValidateNormalizeConvert = function (recordKey, fieldKey, newValue, bIsLocalized, fnCallback, fnError) {

            basePropType.BeginValidateNormalizeConvert.apply(this, [recordKey, fieldKey, newValue, bIsLocalized, PostProcess, fnError]);
            function PostProcess(result) {
                result.isValid = result.isValid && (!newValue || newValue.length <= 255);
                result.dataValue = result.normalizedLocValue = newValue;

                if (!result.isValid) {
                    result.errorMsg = 'Text is too long. 255 characters are allowed for the field.';
                }

                fnCallback(result);
            }
        };
        SP.JsGrid.PropertyType.RegisterNewDerivedCustomPropType(customStringPropType, 'String');
    }
};

GIDisplayControl = function () {
    this.Id = "GIDisplayControl";

    this.Render = function (cellValue, record, column, fieldMapRow, propType, style, jsGridObj, objBagRTL) {
        var localizedValue = cellValue.localized;

        if (typeof localizedValue !== 'undefined' && localizedValue != '') {
            var indicators = localizedValue.split(';');
            if (indicators.length > 0) {
                var div = document.createElement('div');
                div.style.cssText = 'text-align:center';
                for (var i = 0; i < indicators.length; i++) {
                    var deserializedData = Sys.Serialization.JavaScriptSerializer.deserialize(indicators[i]);
                    if (deserializedData.indicatorIndex > 0) {
                        var img = document.createElement('img');
                        img.style.cssText = 'border:0px';
                        img.src = String.format('/_layouts/inc/PWA/images/cf_{0}p.png', deserializedData.indicatorIndex - 1);
                        img.title = deserializedData.localizedValue;
                        div.innerHTML = div.innerHTML + img.outerHTML;
                    }
                }
                return div;
            }
        }
    };
};
GIPropType = function () {
    this.ID = "GIPropType";
    this.GetDisplayValue = function (record, dataValue, locValue) {
        return locValue;
    };
};

RichTextDisplayControl = function () {
    this.Id = "RichTextDisplayControl";

    this.Render = function (cellValue, record, column, fieldMapRow, propType, style, jsGridObj, objBagRTL) {
        var localizedValue = cellValue.localized;

        if (typeof localizedValue != 'undefined' && localizedValue != '') {
            var div = document.createElement('div');
            div.style.height = '15px';
            div.style.overflow = 'hidden';
            div.style.padding = '0px 4px';
            div.innerHTML = localizedValue.replace(/(<([^>]+)>)/ig, " "); ;
            return div;
        }
    };
};

RichTextEditControl = function (gridContext) {
    ULSwSw: ;
    this.SupportedWriteMode = SP.JsGrid.EditActorWriteType.DataOnly;
    this.SupportedReadMode = SP.JsGrid.EditActorReadType.DataOnly;
    var _this = this;
    var _parentNode = gridContext.parentNode;
    var _cellContext;
    var mainDiv;
    function Init() {

        gridContext.bLightFocus = true;
        mainDiv = document.createElement('div');
        mainDiv.style.cssText = 'position:absolute; visibility:hidden; overflow: hidden;';
        $addHandler(mainDiv, 'dblclick', ShowRichTextEditor);
        _parentNode.appendChild(mainDiv);
    }
    this.Dispose = function () {
        _parentNode.removeChild(mainDiv);
    };
    this.BindToCell = function (cellContext) {
        _cellContext = cellContext;
        LayoutControl();
    };
    this.OnCellMove = function () {
        LayoutControl();
    };
    function LayoutControl() {
        mainDiv.style.width = _cellContext.cellWidth + 'px';
        mainDiv.style.height = _cellContext.cellHeight + 'px';

        _cellContext.Show(mainDiv);
    }
    this.Unbind = function () {
        _cellContext.Hide(mainDiv);
    };
    this.OnEndEdit = function () {
    };
    this.OnValueChanged = function () {

    }
    this.OnKeyDown = function (eventInfo) {
        SP.Internal.DomElement.StopEvent(eventInfo);
        return false;
    }
    this.OnBeginEdit = function (eventInfo) {
        _cellContext.NotifyEditComplete();
        SP.Internal.DomElement.StopEvent(eventInfo);
        return false;
    };
    this.OnEndEdit = function () {
    };

    function ShowRichTextEditor() {
        var options = {
            allowautoresize: false,
            allowmaximize: false,
            width: 800,
            height: 300
        };

        var oArguments = mainDiv.innerHTML;

        PJShowWSSModalDialog(
            'RichTextEditor.aspx' + (_cellContext.fieldKey == 'WPROJ_DESCRIPTION' ? '?IsPlainText=true' : ''),
            options,
            fnRichTextEditorCallback,
            oArguments);
    }
    function fnRichTextEditorCallback(oDialogResult, oRet) {
        ULSjSZ: ;
        if (oDialogResult) {

            _cellContext.SetCurrentValue({ data: oRet, localized: oRet });
            _cellContext.NotifyEditComplete();

            mainDiv.innerHTML = oRet;
        }
    }

    Init();
};

RichTextWidget = function (gridContext) {
    ULSwSw: ;
    this.SupportedWriteMode = SP.JsGrid.EditActorWriteType.LocalizedOnly;
    this.SupportedReadMode = SP.JsGrid.EditActorReadType.LocalizedOnly;
    var _parentNode = gridContext.parentNode;
    var _cellContext;
    var _box, _anchor, _iframe;
    var _widgetHeight = 200;
    var _this = this;
    var _curValue;

    this.Dispose = function () {
    }
    this.BindToCell = function (cellContext) {
        _cellContext = cellContext;
        _curValue = (_cellContext.originalValue.localized == SP.JsGrid.EmptyValue) ?
				'' : _cellContext.originalValue.localized;
    }
    this.Unbind = function () {
        _curValue = null;
    }
    this.Expand = function () {
        var options = {
            allowautoresize: false,
            allowmaximize: false,
            width: 800,
            height: 300
        };

        var oArguments = _curValue;

        PJShowWSSModalDialog(
            'RichTextEditor.aspx' + (_cellContext.fieldKey == 'WPROJ_DESCRIPTION' ? '?IsPlainText=true' : ''),
            options,
            fnRichTextEditorCallback,
            oArguments);
    }
    this.GetIcon = function () {
        return new SP.JsGrid.Image('../images/editheader.png').Render(SP.JsGrid.Res.openCalendar);
    }
    this.Collapse = function () {
        _cellContext.NotifyCollapseWidget();
    }
    this.OnValueChanged = function (newValue) {
        _curValue = newValue.localized;
    }

    function fnRichTextEditorCallback(oDialogResult, oRet) {
        ULSjSZ: ;
        if (oDialogResult) {

            _cellContext.SetCurrentValue({ data: oRet, localized: oRet });
            _cellContext.NotifyEditComplete();

            _curValue = oRet;
        }
    }
}

RichTextPropType = function () {
    this.ID = "RichTextPropType";
    this.GetDisplayValue = function (record, dataValue, locValue) {
        return locValue;
    };

    this.BeginValidateNormalizeConvert = function (recordKey, fieldKey, newValue, bIsLocalized, fnCallback, fnError) {

        newValue = (newValue != null && newValue.length == 0) ? '' : newValue;
        var result = {};
        result.isValid = !newValue || newValue.length <= 4000;
        result.dataValue = result.normalizedLocValue = newValue;

        if (!result.isValid) {
            result.errorMsg = 'Text is too long. 4000 characters are allowed for the field.';
        }

        fnCallback(result);
    }
};

ProjectOwnerDisplayControl = function () {
    this.Id = "ProjectOwnerDisplayControl";

    this.Render = function (cellValue, record, column, fieldMapRow, propType, style, jsGridObj, objBagRTL) {
        var localizedValue = cellValue.localized;

        if (typeof localizedValue !== 'undefined' && localizedValue != '') {
            var div = document.createElement('div');
            div.style.overflow = 'hidden';
            div.style.padding = '0px 4px';
            div.innerHTML = localizedValue;
            div.title = localizedValue;
            return div;
        }
    };
};

ProjectOwnerEditControl = function (gridContext) {
    ULSwSw: ;
    this.SupportedWriteMode = SP.JsGrid.EditActorWriteType.DataOnly;
    this.SupportedReadMode = SP.JsGrid.EditActorReadType.DataOnly;
    var _this = this;
    var _parentNode = gridContext.parentNode;
    var _cellContext;
    var mainDiv, editIcon;
    var paddingTopBottom = 3;
    var paddingLeftRight = 4;
    
    function Init() {
        gridContext.bLightFocus = true;
        mainDiv = document.createElement('div');
        mainDiv.style.cssText = 'position:absolute; visibility:hidden; background-color:#ffffff; overflow: hidden; color: #131519; font-family: Tahoma; font-size: 1em;';
        mainDiv.style.padding = paddingTopBottom + 'px ' + paddingLeftRight + 'px';
        $addHandler(mainDiv, 'dblclick', ShowResPickerEditor);
        _parentNode.appendChild(mainDiv);

        editIcon = document.createElement('div');
        editIcon.title = 'Set Project Owner';
        editIcon.style.cssText = 'position:absolute; visibility:hidden;';
        editIcon.className = 'edit-icon';
        editIcon.innerHTML = '<div><IMG src="../images/editheader.png" /></div>';
        $addHandler(editIcon, 'click', ShowResPickerEditor);
        $addHandler(editIcon, 'mouseover', function () { editIcon.style.backgroundColor = '#C4C9CF'; });
        $addHandler(editIcon, 'mouseout', function () { editIcon.style.backgroundColor = '#E3E6E8'; });
        _parentNode.appendChild(editIcon);
    }
    this.Dispose = function () {
        _parentNode.removeChild(mainDiv);
        _parentNode.removeChild(editIcon);
    };
    this.BindToCell = function (cellContext) {
        _cellContext = cellContext;
        mainDiv.innerHTML = _cellContext.originalValue.localized ? _cellContext.originalValue.localized : '';
        mainDiv.title = mainDiv.innerHTML;
        LayoutControl();
    };
    this.OnCellMove = function () {
        LayoutControl();
    };
    function LayoutControl() {
        mainDiv.style.width = (_cellContext.cellWidth - (2 * paddingLeftRight)) + 'px';
        mainDiv.style.height = (_cellContext.cellHeight - (2 * paddingTopBottom)) + 'px';

        _cellContext.Show(mainDiv);
        _cellContext.Show(editIcon);

        editIcon.style.top = (_cellContext.cellExpandSpace.top + 1) + 'px';
        editIcon.style.left = (_cellContext.cellExpandSpace.left + _cellContext.cellWidth + 30) + 'px';
        editIcon.style.clip = 'auto';
        editIcon.style.position = 'absolute';
    }
    this.Unbind = function () {
        _checkboxActive = false;
        _cellContext.Hide(mainDiv);
        _cellContext.Hide(editIcon);
    };
    this.OnEndEdit = function () {
    };
    this.OnValueChanged = function () {
    }
    this.OnKeyDown = function (eventInfo) {
        SP.Internal.DomElement.StopEvent(eventInfo);
        return false;
    }
    this.OnBeginEdit = function (eventInfo) {
        _cellContext.NotifyEditComplete();
        SP.Internal.DomElement.StopEvent(eventInfo);
        return false;
    };
    this.OnEndEdit = function () {
    };

    function ShowResPickerEditor() {
        var options = {
            allowautoresize: false,
            allowmaximize: false,
            width: 600,
            height: 400
        };

        PJShowWSSModalDialog(
            '../PWA/Common/ResPicker.aspx?Query=&Flavor=7&SelectionRequired=1',
            options,
            fnResPickerEditorCallback);
    }
    function fnResPickerEditorCallback(oDialogResult, oRet) {
        if (oDialogResult) {

            _cellContext.SetCurrentValue({ data: oRet.Guid, localized: oRet.Name });
            _cellContext.NotifyEditComplete();

            mainDiv.innerHTML = oRet.Name;
            mainDiv.title = oRet.Name;
        }
    }

    Init();
};

ProjectOwnerPropType = function () {
    this.ID = "ProjectOwnerPropType";
    this.GetDisplayValue = function (record, dataValue, locValue) {
        return locValue;
    };

    this.BeginValidateNormalizeConvert = function (recordKey, fieldKey, newValue, bIsLocalized, fnCallback, fnError) {

        fnCallback({ isValid: true, dataValue: newValue, normalizedLocValue: newValue });
    }
};