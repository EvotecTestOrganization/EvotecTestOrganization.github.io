﻿namespace DemandManagement.BulkEditTool
{
    public partial class BulkEdit
    {
        protected global::Microsoft.Office.Project.PWA.CommonControls.PageProperty idPageProperty;
        protected global::Microsoft.SharePoint.WebControls.JSGrid gridProjects;
    }
}
