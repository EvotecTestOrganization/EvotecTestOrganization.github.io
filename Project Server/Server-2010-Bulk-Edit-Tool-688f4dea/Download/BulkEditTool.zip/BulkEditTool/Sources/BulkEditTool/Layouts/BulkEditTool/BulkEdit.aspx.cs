﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Web.Script.Serialization;
using System.Web.UI;
using DemandManagement.BulkEditTool.DTO;
using DemandManagement.BulkEditTool.JSGrid;
using DemandManagement.BulkEditTool.Services;
using Microsoft.Office.Project.PWA;
using Microsoft.Office.Project.Server.Library;
using Microsoft.Office.Project.Server.Schema;
using Microsoft.SharePoint;
using Microsoft.SharePoint.JSGrid;
using Microsoft.SharePoint.JsonUtilities;
using Microsoft.SharePoint.WebControls;

namespace DemandManagement.BulkEditTool
{
    public partial class BulkEdit : PJWebPage, ICallbackEventHandler
    {
        public override void PJWebPage_OnLoad(EventArgs e)
        {
            base.PJWebPage_OnLoad(e);

            if (!ServicePointManager.ServerCertificateValidationCallback.GetInvocationList().Contains(new RemoteCertificateValidationCallback(Utils.ServerCertificateValidation)))
                ServicePointManager.ServerCertificateValidationCallback += Utils.ServerCertificateValidation;

            if (!IsPostBack)
            {
                InitRibbon();
                var resources = new Dictionary<string, string>();

                var enumerator = GlobalResources.BulkEditTool.ResourceManager
                    .GetResourceSet(CultureInfo.CurrentCulture, true, true)
                    .GetEnumerator();
                while (enumerator.MoveNext())
                    resources.Add((string)enumerator.Key, (string)enumerator.Value);

                gridProjects.JsInitObject = new
                                                {
                                                    pwa = PjContext.SitePath,
                                                    callbackScript = ClientScript.GetCallbackEventReference(
                                                        this, "args", "GM.DisplayProjectsData", "true", true),
                                                    resources
                                                };
            }
        }        

        private void InitRibbon()
        {
            var ribbon = SPRibbon.GetCurrent(this);
            ribbon.Minimized = false;
            ribbon.CommandUIVisible = true;
            const string tabId = "Ribbon.Tabs.BulkEditTool.BulkEdit";
            if (!ribbon.IsTabAvailable(tabId))
                ribbon.MakeTabAvailable(tabId);
            ribbon.InitialTabId = tabId;
        }

        private Guid _currentUserUid;
        private Guid CurrentUserUid
        {
            get
            {
                if (_currentUserUid == Guid.Empty)
                {
                    _currentUserUid = PJContext.Current.PSI.ResourceWebService.GetCurrentUserUid();
                }
                return _currentUserUid;
            }
        }

        #region ICallbackEventHandler Members

        public new string GetCallbackResult()
        {
            string gridJson = null;
            object commandContext = null;
            var updateJobs = new Dictionary<string, object>();
            Guid[] shownProjectsUids;
            switch (_callbackArgs.Command)
            {
                case "ShowProjects":
                    gridJson = GetProjectsJson(
                        false,
                        _callbackArgs.SelectedProjects,
                        out shownProjectsUids,
                        _callbackArgs.OrderByColumnName ?? GridUtilities.PROJ_NAME_COLUMN_NAME,
                        _callbackArgs.IsDescending);

                    foreach (var projectUid in shownProjectsUids)
                    {
                        using (var dsQueuedJobs = PJContext.Current.PSI.QueueSystemWebService.ReadProjectJobStatus(
                                                        new[] { projectUid },
                                                        new[] { QueueConstants.QueueMsgType.ProjectUpdate },
                                                        new[]
                                                            {
                                                                QueueConstants.JobState.OnHold,
                                                                QueueConstants.JobState.ProcessingDeferred,
                                                                QueueConstants.JobState.ReadyForLaunch,
                                                                QueueConstants.JobState.ReadyForProcessing,
                                                                QueueConstants.JobState.SendIncomplete,
                                                                QueueConstants.JobState.Sleeping,
                                                                QueueConstants.JobState.Unknown
                                                            },
                                                        DateTime.Now.AddYears(-1),
                                                        DateTime.Now,
                                                        0,
                                                        true, QueueConstants.SortColumn.Undefined,
                                                        QueueConstants.SortOrder.Undefined))
                        {
                            var jobUid = dsQueuedJobs.Status.Rows
                                .Cast<QueueStatusDataSet.StatusRow>()
                                .Where(_ => _.ResourceGUID == CurrentUserUid)
                                .Select(_ => _.JobGUID)
                                .FirstOrDefault();
                            if (jobUid != Guid.Empty)
                            {
                                updateJobs.Add(projectUid.ToString(), new { jobUid });
                            }
                        }
                    }
                    
                    commandContext = new { updateJobs };
                    break;
                case "EditProjects":
                    gridJson = GetProjectsJson(
                        true,
                        _callbackArgs.SelectedProjects,
                        out shownProjectsUids,
                        _callbackArgs.OrderByColumnName ?? GridUtilities.PROJ_NAME_COLUMN_NAME,
                        _callbackArgs.IsDescending);
                    break;
                case "SaveProjects":
                    var changes = _callbackArgs.Changes.ToDictionary(_ => new Guid(_.Key), _ => _.Value);
                    try
                    {
                        updateJobs = new GridData().Update(changes).ToDictionary(_ => _.Key.ToString(), _ => _.Value);
                    }
                    catch
                    {
                        Debugger.Break();
                    }
                    try
                    {
                        gridJson = GetProjectsJson(
                        false,
                        null,
                        out shownProjectsUids,
                        _callbackArgs.OrderByColumnName ?? GridUtilities.PROJ_NAME_COLUMN_NAME,
                        _callbackArgs.IsDescending);
                    }
                    catch
                    {
                        Debugger.Break();
                    }
                    commandContext = new { updateJobs };
                    break;
                default:
                    throw new NotImplementedException();
            }

            return new JavaScriptSerializer().Serialize(new
                                                            {
                                                                gridJson,
                                                                commandContext
                                                            });
        }

        private CallbackArgs _callbackArgs;
        public new void RaiseCallbackEvent(string eventArgument)
        {
            //deserialize callback arguments from JSON
            _callbackArgs = new JavaScriptSerializer()
                .Deserialize<CallbackArgs>(eventArgument);
        }

        #endregion

        #region Private methods

        private string GetProjectsJson(bool isEditMode, Guid[] selectedProjects, out Guid[] shownProjectsUids, string orderByColumnName, bool isDescending)
        {
            //get fields list to show

            List<PSFieldInfo> allFields = null;
            
            SPSecurity.RunWithElevatedPrivileges(() => allFields = new FieldsService().GetProjectFields().ToList());
                
            var fieldsToShow = _callbackArgs.SelectedFields
                .Select(fieldUid => allFields.First(_ => _.Uid == fieldUid));

            if (_callbackArgs.FilterBy != null)
            {
                _callbackArgs.FilterBy
                    .ToList()
                    .ForEach(_ => _.FieldInfo = allFields.First(f => f.Uid == _.FieldUid));
            }

            //get projects data
            var data = new GridData().Data(fieldsToShow, _callbackArgs.FilterBy, selectedProjects, isEditMode);

            shownProjectsUids = data.Rows.Cast<DataRow>().Select(_ => (Guid) _[GridUtilities.KEY_COLUMN_NAME]).ToArray();

            //create a grid serializer to connect to data
            var gds = new GridSerializer(SerializeMode.Full, data,
                                         GridUtilities.KEY_COLUMN_NAME,
                                         new FieldOrderCollection(
                                            new[] { orderByColumnName },
                                            new[] { isDescending }),
                                         GridUtilities.GetGridFields(data, isEditMode), GridUtilities.GetGridColumns(data));

            //register YesNoUncknown dropdown for editing flag fields
            gds.RegisterPropLookupType(GridUtilities.YesNoUnknownlookupTypeInfo);
            gds.RegisterPropLookupType(GridUtilities.ProjectTypeLookupTypeInfo);

            //register objects for using CustomFieldWidget widget
            gds.AdditionalParams["CustomFieldInfo"] = GridUtilities.GetCustomFieldInfoObject(fieldsToShow);
            gds.AdditionalParams["CustomFieldLookupTableInfo"] = GridUtilities.GetCustomFieldLoolupTableInfoObject(fieldsToShow);

            var serializer = new Serializer(
                new Dictionary<Type, JsonEncoder>
                    {
                        {
                            typeof (Uid),
                            (Serializer s, object obj) => s.SerializeToJson(obj.ToString())
                        }
                    });
            return gds.ToJson(serializer);
        }

        #endregion

    }

    /// <summary>
    /// Used for deserializing callback arguments from Json
    /// </summary>
    public class CallbackArgs
    {
        public string Command;
        public FilterItem[] FilterBy;
        public Guid[] SelectedFields;
        public Guid[] SelectedProjects;
        public Dictionary<string, Dictionary<string, object>> Changes;
        public String OrderByColumnName;
        public bool IsDescending;
    }

    public class FilterItem
    {
        public Guid FieldUid;
        public string Test;
        public string Value;
        public string Operator;

        public PSFieldInfo FieldInfo;
    }
}
