Blog can be found at:
Create a Power BI report that shows all files in Project Online
https://www.theprojectcornerblog.com/?p=3238

Video instruction can be found at:
https://youtu.be/HZ0sV0OXewE

Make sure to sign up for more:
http://eepurl.com/dslcnP