﻿<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#> 

#requires -Version 2

Function Repair-OSCPrinter
{
<#
	.SYNOPSIS
	Function Repair-OSCPrinter is an advanced function which can clear Printing Subsystem.
	.DESCRIPTION
	Function Repair-OSCPrinter is an advanced function which can clear Printing Subsystem.
	.PARAMETER FixPrinter
	Clear Printing Subsystem 
	.PARAMETER RestoreREG
	Restore the registry key 
	.EXAMPLE
	Repair-OSCPrinter -FixPrinter
	
	Clear Printing Subsystem 
	.EXAMPLE
	Repair-OSCPrinter -RestoreREG
	
	Restore the registry key 	
#>

	Param 
	(   
		[CmdletBinding(SupportsShouldProcess=$true)]
	    [Parameter(Mandatory=$False,Position = 0,ParameterSetName="Fix")]
	    [Switch]$FixPrinter,
		[Parameter(Mandatory=$False,Position = 1,ParameterSetName="Restore")]
	    [Switch]$RestoreREG
	)
	Switch($pscmdlet.ParameterSetName)
	{
		"Fix" 
		{
			Try 
			{
				#Stop spooler service
				if(Stop-Service -Name Spooler  -Force -ErrorAction Stop )
				{
					Write-Host "Stoping the Spooler Service!"
				}
				Write-Host "Deleting old files and folders!" 
				#Delete files or folders
				Get-ChildItem -Path "C:\Windows\System32\Spool\Printers" | Remove-Item 
				Get-ChildItem -Path "C:\Windows\System32\Spool\Drivers\w32x86" | Remove-Item 
				write-host "Backup registry key HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows NT x86 as NTX86.REG" 
				#Back up registry key
				REG EXPORT "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows NT x86" NTX86.REG
				$NT86Item = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows NT x86\Drivers",`
				"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows NT x86\Print Processors"
				Write-Host "Deleting registry key in HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows NT x86" 
				#Delete the key other than in $NTX86Item
				Get-ChildItem -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows NT x86" | `
				Where-Object {$NT86Item -notcontains $_.Name} |Remove-Item
				write-host "Backup registry key HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Monitors as Monitors.REG" 
				#Backuo monitors key as Monitor.REG
				REG Export "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Monitors" Monitors.REG
				$MonItems = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Monitors\BJ Language Monitor",`
				"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Monitors\Local Port",`
				"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Monitors\PJL Language Monitor ",`
				"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Monitors\Standard TCP/IP Port",`
				"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Monitors\USB Monitor",`
				"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Monitors\WSD Port"
				Write-Host "Deleting registry key in HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Print\Monitors" 
				#Delete the key other than in $MonItems
				Get-ChildItem -LiteralPath "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Monitors"|
				Where-Object {$MonItems -notcontains $_.Name }|remove-item
				Write-Host "Starting the Spooler Service!" 
				#Start the spooler service
				Start-Service -Name Spooler  
				Write-Host "Operation done!Try it."
			}
			Catch [Microsoft.PowerShell.Commands.StopServiceCommand]
			{
				Write-Error "Could not stop service ,please ensure you have the permission!"
			}
		}
		"Restore"
		{	
			#Import the NTX86.REG
			Write-Host "Importing NTX86.REG"	
			REG IMPORT NTX86.REG
			#Import Monitors.REG
			Write-Host "Importing Monitors.REG"
			REG IMPORT Monitors.REG
		}
	}
	
}
