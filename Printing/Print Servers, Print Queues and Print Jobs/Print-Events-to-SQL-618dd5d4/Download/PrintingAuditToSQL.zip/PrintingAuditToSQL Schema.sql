USE [PA]
GO

/****** Object:  Table [dbo].[PrintEvents]    Script Date: 07/13/2011 10:59:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[PrintEvents](
	[PrintId] [bigint] IDENTITY(1,1) NOT NULL,
	[PrintServer] [varchar](40) NOT NULL,
	[EventRecordId] [bigint] NULL,
	[EventID] [int] NOT NULL,
	[PrintDate] [datetime] NOT NULL,
	[PrintUser] [varchar](30) NULL,
	[PrintedFrom] [varchar](30) NULL,
	[PrinterName] [varchar](60) NULL,
	[JobId] [int] NULL,
	[DocumentName] [varchar](max) NULL,
	[DocumentSize] [int] NULL,
	[Pages] [smallint] NULL,
	[Copies] [smallint] NULL,
	[RawMessage] [varchar](max) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The record number assigned to the event when it was logged.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PrintEvents', @level2type=N'COLUMN',@level2name=N'EventRecordId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'The identifier that the provider used to identify the event.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PrintEvents', @level2type=N'COLUMN',@level2name=N'EventID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Date and time that the job begins. ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PrintEvents', @level2type=N'COLUMN',@level2name=N'PrintDate'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'User that submitted the job. ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PrintEvents', @level2type=N'COLUMN',@level2name=N'PrintUser'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Name of the computer on which the print job is created.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PrintEvents', @level2type=N'COLUMN',@level2name=N'PrintedFrom'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Name of the print job. The user sees this name when viewing documents that are waiting to be printed.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PrintEvents', @level2type=N'COLUMN',@level2name=N'DocumentName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Size of the print job in bytes' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PrintEvents', @level2type=N'COLUMN',@level2name=N'DocumentSize'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Number of pages that are printed. This value may be 0 (zero) if the print job does not contain page-delimiting information.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PrintEvents', @level2type=N'COLUMN',@level2name=N'Pages'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Generic unparsed event details' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PrintEvents', @level2type=N'COLUMN',@level2name=N'RawMessage'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Identifier number of the job. It is used by other methods as a handle to a job spooling to the printer.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PrintEvents', @level2type=N'COLUMN',@level2name=N'JobId'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'Number of copies to be printed. The printer driver must support printing multi-page copies.' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'PrintEvents', @level2type=N'COLUMN',@level2name=N'Copies'
GO



USE [PA]
GO

/****** Object:  Index [IDX_307]    Script Date: 07/12/2011 14:21:22 ******/
CREATE NONCLUSTERED INDEX [IDX_307] ON [dbo].[PrintEvents] 
(
	[EventID] ASC
)
INCLUDE ( [PrintDate],
[PrintUser],
[PrinterName],
[DocumentName],
[DocumentSize],
[Pages]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO


