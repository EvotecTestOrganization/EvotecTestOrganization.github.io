<########################################################################################
AUTHOR:           Chris Bell (CDBELL@UW.EDU)

DESCRIPTION:      Parses the Windows 2008 R2 print event logs and stores them into a SQL db.

VERSION HISTORY:
1.4 2012-02-15 - Switched to PROD server
1.3 2012-01-13 - Added EventID 302-304 (CDBELL)
1.2 2011-07-14 - Additional error handling for XML conversion (CDBELL)
1.1 2011-07-13 - Added EventID 805 (CDBELL)
1.0 2011-07-12 - Initial release (CDBELL)
#########################################################################################>

# server to query for the events
$PRINT_SERVER = get-content env:computername

## SQL VARIABLES ##
$PROD_SERVER = "ITS-x"
$DEV_SERVER = "ITS-z"
$DATABASE = "Rx_PA"
$TABLE = "PrintEvents"
$SQL_RECORD_SCHEMA = "SET FMTONLY ON; SELECT TOP 1 * FROM $TABLE"
$connectionString = "Data Source=$PROD_SERVER;Initial Catalog=$DATABASE;Integrated Security=SSPI;"

function Set-ProcessPrioritybyPid
{ 
    param($processPid = $(throw "Enter process PID"), $priority = "Normal")
    trap {$false; continue}

    get-process -id $processPid | foreach { $_.PriorityClass = $priority }
    write-host "`"$($processPid)`"'s priority is set to `"$($priority)`""
}

function ConvertTo-NtAccount ($sid) 
{
    (new-object system.security.principal.securityidentifier($sid)).translate([system.security.principal.ntaccount])
}

function ConvertTo-Sid ($NtAccount) 
{
    (new-object system.security.principal.NtAccount($NTaccount)).translate([system.security.principal.securityidentifier])
}

function Get-DataTable([string]$query)
{
    trap {$false; continue}
    
	$dataSet= new-object "System.Data.DataSet" "DataSetName"
	$da = new-object "System.Data.SqlClient.SqlDataAdapter" ($query, $connectionString)
	[void] $da.Fill($dataSet)
	return ,$dataSet.Tables[0] #prevent PowerShell from unrolling collections
}

function Get-SQL ([string]$query) 
{
    trap {$false; continue}
    
    $Connection = New-Object System.Data.SQLClient.SQLConnection
    $Connection.ConnectionString = $connectionString
    $Connection.Open()

    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    $Command.CommandText = $query

    $Reader = $Command.ExecuteReader()
    $Counter = $Reader.FieldCount
    while ($Reader.Read()) 
    {
        $SQLObject = @{}
        for ($i = 0; $i -lt $Counter; $i++) 
        {
            $SQLObject.Add(
                $Reader.GetName($i),
                $Reader.GetValue($i));
        }
    
        $SQLObject
    }
    
    $Connection.Close()
}

function Get-LastEventIDbyDate
{
    param($eventid)
    trap {$false; continue}
    
    $results = Get-SQL "SELECT MAX(printdate) from $TABLE where EventID=$eventid AND PrintServer LIKE '$PRINT_SERVER%'" 
        
    if ($results.count -gt 0)
    {
        # Safe assumption since the SQL query always only returns 1 row.
        $lastdate = $results.keys | foreach {$results.$_}                
        return $lastdate
    }
}

function Write-DataTableToDatabase
{ 
    param($dt,$destTbl)
    trap {$false; continue}
    
	try
	{
	    $dtrows = $dt.Rows.count
	    Write-Host "Copying $dtrows rows to $destTbl..."
	    $bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $connectionString
	    $bulkCopy.DestinationTableName = "$destTbl"
	    $bulkCopy.WriteToServer($dt)
	    $bulkCopy.close()
	}
	catch
    {
        $msg = $_.Exception.Message.Trim().Replace("`n",'') 
        Write-Host -foregroundcolor Red $msg        
    } 
}

function ParseEventId300
{
    param($row, $entry)
    trap {$false; continue}
    
    $row.PrinterName = $entry.Event.UserData.PrinterCreated.Param1    
}

function ParseEventId301
{
    param($row, $entry)
    trap {$false; continue}
    
    $row.PrinterName = $entry.Event.UserData.PrinterDeleted.Param1    
}

function ParseEventId302
{
    param($row, $entry)
    trap {$false; continue}
    
    $row.PrinterName = $entry.Event.UserData.PrinterDeletionPending.Param1    
}

function ParseEventId303
{
    param($row, $entry)
    trap {$false; continue}
    
    $row.PrinterName = $entry.Event.UserData.PrinterPaused.Param1    
}

function ParseEventId304
{
    param($row, $entry)
    trap {$false; continue}
    
    $row.PrinterName = $entry.Event.UserData.PrinterUnPaused.Param1    
}

function ParseEventId306
{
    param($row, $entry)
    trap {$false; continue}
    
    $row.PrinterName = $entry.Event.UserData.PrinterSet.Param1    
}

function ParseEventId307
{
    param($row, $entry)
    trap {$false; continue}    

    $row.JobId = $entry.Event.UserData.DocumentPrinted.Param1 
    $row.DocumentName = $entry.Event.UserData.DocumentPrinted.Param2
    $row.PrintUser = $entry.Event.UserData.DocumentPrinted.Param3
    $row.PrintedFrom = $entry.Event.UserData.DocumentPrinted.Param4
    $row.PrinterName = $entry.Event.UserData.DocumentPrinted.Param5
    $row.DocumentSize = $entry.Event.UserData.DocumentPrinted.Param7
    $row.Pages = $entry.Event.UserData.DocumentPrinted.Param8    
}

function ParseEventId805
{
    param($row, $entry)
    trap {$false; continue}
    
    $row.JobId = $entry.Event.UserData.RenderJobDiag.JobId
    $row.Copies = $entry.Event.UserData.RenderJobDiag.Copies    
}

function Get-PrintEvents
{
    param($eventid)
    trap {$false; continue}
    
    Write-Host "Collecting new EventID $eventid events " -NoNewline
    $StartDate = Get-LastEventIDbyDate $eventid
    
    if (($StartDate -eq $null) -or $StartDate -eq [dbnull]::value)
    { 
        #no previous event found. Get last 180 days worth
        $StartDate = (get-date) - (new-timespan -day 180) 
    }
    else
    { 
        #increment the starting date/time so the same one isnt retrieve again
        $StartDate = $StartDate.AddSeconds(1.0) 
    } 

    write-host "using start date: $StartDate"
    #Get-WinEvent requires Windows Vista, Windows Server 2008 R2, or later
    $PrintEntries = Get-WinEvent -ea SilentlyContinue -ComputerName $PRINT_SERVER -FilterHashTable @{ProviderName="Microsoft-Windows-PrintService"; StartTime=$StartDate; ID=$eventid} -Oldest 
    
    if ($PrintEntries -ne $null)
    {    
        $newevents = $PrintEntries.Count    
        write-Host "`tParsing $newevents EventID $eventid event log entries..."

        ForEach ($PrintEntry in $PrintEntries)
        {   		
			try
			{
	            $row = $datatable.NewRow()
				# rarely there are invalid characters in the XML stream which fails
	            $entry = [xml]$PrintEntry.ToXml() 
	            
	            #write-host $PrintEntry
	            #write-host $entry.Event
	            
	            #common fields
	            $row.PrintDate = $PrintEntry.TimeCreated
	            $row.RawMessage = $PrintEntry.Message            
	            $row.EventRecordId = $entry.Event.System.EventRecordID
	            $row.EventId = $entry.Event.System.EventID
	            $row.PrintServer = $entry.Event.System.Computer
	            $row.PrintUser = ConvertTo-NtAccount $entry.Event.System.Security.UserID
	            
	            #event specific fields
	            switch ($eventid)            
	            {   
	                300 {ParseEventId300 $row $entry}
	                301 {ParseEventId301 $row $entry}
					302 {ParseEventId302 $row $entry}
					303 {ParseEventId303 $row $entry}
					304 {ParseEventId304 $row $entry}
	                306 {ParseEventId306 $row $entry}
	                307 {ParseEventId307 $row $entry}
	                316 {} #no additional parsing                
	                805 {ParseEventId805 $row $entry}
	                default {}
	            }
	            
	            $datatable.Rows.Add($row)  
			}
			catch
		    {
		        $msg = $_.Exception.Message.Trim().Replace("`n",'') 
		        Write-Host -foregroundcolor Red $msg        
		    }    
		}    
	}
}

######## code start ########
# lower priority so doesn't impact system
Set-ProcessPrioritybyPid $pid "Idle"

$datatable = Get-DataTable $SQL_RECORD_SCHEMA
$datatable.Rows.Clear()
Get-PrintEvents 300  #Printer %1 was created.
Get-PrintEvents 301  #Printer %1 was deleted...
Get-PrintEvents 302  #Printer %1 will be deleted. 
Get-PrintEvents 303  #Printer %1 was paused.
Get-PrintEvents 304  #Printer %1 was resumed
Get-PrintEvents 306  #Settings for printer %1 were changed.
Get-PrintEvents 307  #Document %1, %2 owned by %3 on %4 was printed on %5...
Get-PrintEvents 316  #Printer driver %1 for %2 %3 was added or updated.
Get-PrintEvents 805  #Rendering job %1.
#$datatable
Write-DataTableToDatabase $datatable $TABLE
Exit