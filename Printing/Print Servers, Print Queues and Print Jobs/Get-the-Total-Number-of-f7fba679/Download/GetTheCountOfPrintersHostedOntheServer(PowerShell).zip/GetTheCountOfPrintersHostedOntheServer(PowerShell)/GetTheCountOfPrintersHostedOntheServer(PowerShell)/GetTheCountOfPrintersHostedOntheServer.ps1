﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#Requires -Version 2.0

# Message for the script
$Message = new-object PSObject
$Message | Add-Member NoteProperty RunasAdmin `
	"To run this script you need to run PowerShell console in ""Run as Administrator"" mode."

Function Get-OSCIsServerANodeOfFailoverCluster{
<#
 	.SYNOPSIS
        Get-OSCIsServerANodeOfFailoverCluster is a function can be used to 
		check whether the current Server is a node of a failover cluster.
		
    .DESCRIPTION
        Get-OSCIsServerANodeOfFailoverCluster is a function can be used to 
		check whether the current Server is a node of a failover cluster.
		
    .EXAMPLE
		Get-OSCIsServerANodeOfFailoverCluster 
		Check whether the current Server is a node of a failover cluster.
		
	.LINK
		
#>
	# Environment params
	$IsServerANodeOfFailoverCluster = $false
	
	# Check if run as administrator 
	If(-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()`
		).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")){
		
		Throw $Message.RunasAdmin
	}
	
	Import-Module FailoverClusters -ErrorAction SilentlyContinue
	If (Get-Module FailoverClusters){
		$IsServerANodeOfFailoverCluster = $true
	}
	$IsServerANodeOfFailoverCluster
}

Function Get-OSCAllPrintSpoolerResources{
<#
 	.SYNOPSIS
        Get-OSCAllPrintSpoolerResources is a function can be used to get all 
		the available Print Spooler Resources in the failover clster.
    
	.DESCRIPTION
        Get-OSCAllPrintSpoolerResources is a function can be used to get all 
		the available Print Spooler Resources in the failover clster.
		
    .EXAMPLE
		Get-OSCAllPrintSpoolerResources 
		Get all the available Print Spooler Resources in the failover clster.
		
	.LINK
		
#>

	# Environment params
	$IsServerANodeOfFailoverCluster = $false
	$PrintSpoolerResources = @()

	Try{
		$Error.Clear()
		$IsServerANodeOfFailoverCluster = Get-OSCIsServerANodeOfFailoverCluster
		
		If($IsServerANodeOfFailoverCluster){
			$PrintSpoolerResources = Get-ClusterResource -ErrorAction SilentlyContinue `
			| Where-Object{
				[String]$_.ResourceType -ieq "Print Spooler" -and [String]$_.State -ieq "Online"
			}
		}
	}
	Catch{
		Throw $Error
	}
	
	$PrintSpoolerResources
}

Function Measure-OSCPrinterCountTheServerHosted{
<#
 	.SYNOPSIS
        Measure-OSCPrinterCountTheServerHosted is a function can be used to get the 
		total number of printers that hosted on the current Server.
    
	.DESCRIPTION
        Measure-OSCPrinterCountTheServerHosted is a function can be used to get the 
		total number of printers that hosted on the current Server.
		
    .EXAMPLE
		Measure-OSCPrinterCountTheServerHosted 
		get the total number of printers that hosted on the current Server.
		
	.LINK
		
#>

	# Environment params
	$PrintSpoolerResources = @()
	$PrintsInCurrentResource = @()
	$PrinterCountTheServerHosted = 0

	# Check if run as administrator 
	If(-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()`
		).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")){
		
		Throw $Message.RunasAdmin
	}
	
	Try{
		$PrintSpoolerResources = Get-OSCAllPrintSpoolerResources 
		
		If ($PrintSpoolerResources.Count -gt 0) {
			Foreach($Resource in $PrintSpoolerResources){
				$PrintsInCurrentResource = Get-Item -Path `
					(-join("HKLM:\Cluster\Resources\", $Resource.ID,"\Printers"))`
					-ErrorAction SilentlyContinue
				
				$PrinterCountTheServerHosted += $PrintsInCurrentResource.SubKeyCount
			}
		}
		Else{
			$PrintsInCurrentResource = Get-ChildItem -Path `
				"HKLM:\SYSTEM\CurrentControlSet\Control\Print\Printers"
			
			$PrinterCountTheServerHosted += $PrintsInCurrentResource.Count
		}
	}
	Catch{
		Throw $Error
	}
	
	$OSCPrintServer = new-object PSObject
	$OSCPrintServer | Add-Member NoteProperty PrintServer 				$null 
    $OSCPrintServer | Add-Member NoteProperty PrinterHosted 			$null
	
	$OSCPrintServer.PrintServer = $Env:COMPUTERNAME
	$OSCPrintServer.PrinterHosted = $PrinterCountTheServerHosted
	
	$OSCPrintServer	
}
