﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#Requires -Version 2.0

#Import Localized Data
Import-LocalizedData -BindingVariable Message

Function Remove-OSCEvilPrintQueueRegKey{
<#
    .SYNOPSIS
        Remove-OSCEvilPrintQueueRegKey can be used to delete one or more evil 
		registry keys for print queues in a computer.
		
    .DESCRIPTION
        Remove-OSCEvilPrintQueueRegKey is an advanced function which can be 
		used to delete one or more evil registry keys for print queues in a computer.
		
		Consider the following scenario:
			•You delete a print queue while it is in an Offline status.
			•You add a new print queue that has the same name as the old print 
			queue.
			•You restart the computer.
		In this scenario, the status of the new print queue is displayed as 
		Offline.
		
		To resolve this issue, you can run the cmdlet 
		Remove-OSCEvilPrintQueueRegKey after you delete a print queue but before 
		you add a new print queue of the same name. 

	.PARAMETER  <PrintQueue>
		Delete the evil registry key of the print queue <PrintQueue> 
		in a computer.
		
    .EXAMPLE
        Remove-OSCEvilPrintQueueRegKey
		
        Delete all evil registry keys for print queues in the current computer.
    .EXAMPLE
        Remove-OSCEvilPrintQueueRegKey -PrintQueue <PrintQueue>
		
        Delete evil registry key of the PrintQueue <PrintQueue> in 
		the computer 
#>

    [CmdletBinding()]
	# Parameters for the function
	PARAM
	(
	    [Parameter(Mandatory = $false)]
	    [String]$PrintQueue
	)
	
	#Environment params
	[String] $Computer = $Env:COMPUTERNAME
	[Array] $OSCEvilPrintQueues = $null 
	
	# Check if current user is administrator 
	# To delete the evil registry keys for print queues in a computer you need to run 
	# the function <Remove-OSCEvilPrintQueueRegKey> as administrator.
	If(([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()`
	).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")){
		
		# Get all evil print queues 
		$OSCEvilPrintQueues = Get-OSCPrintQueue -ErrorAction "silentlycontinue" |`
		Where-Object {$_.IsEvilPrintQueue -eq $true}
		
		If($OSCEvilPrintQueues.Count -gt 0){
		
			# Filter a specific evil print queue 
			If($PrintQueue -ne $null -and $PrintQueue -ne ""){
				$OSCEvilPrintQueues = $OSCEvilPrintQueues | `
				Where-Object {$_.PrintQueueName -eq $PrintQueue}
			}
			
			If($OSCEvilPrintQueues.Count -gt 0){
			
				# Open base registry key
				Try{
					$BaseKeyPrintQueues = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(`
					[Microsoft.Win32.RegistryHive]::CurrentConfig,$Computer)
				}
				Catch{
					Write-Error ($Message.FailToOpenBaseKey + " ["+ $Computer + "]")
					return $null 
				}
				
				Try{
					$KeyPrintQueues= $BaseKeyPrintQueues.OpenSubKey(`
					"System\CurrentControlSet\Control\Print\Printers", $true)
				}
				Catch{
					Write-Error ($Message.PrinterNoneSubKey + " ["+ $Computer + "]")
			        return $Null
				}
				
				Foreach($OSCEvilPrintQueue in $OSCEvilPrintQueues){
					$EvilPrintQueueKey = $OSCEvilPrintQueue.PrintQueueName
					
					Try{
						$KeyPrintQueues.DeleteSubKey($EvilPrintQueueKey)
						Write-Host ($Message.DeleteSuccss1 + 
						" [HKEY_CURRENT_CONFIG\System\CurrentControlSet\Control\" +
						"Print\Printers\" + $EvilPrintQueueKey + "] " +$Message.DeleteSuccss2)
					}
					Catch{
						Break
					}
				}
			}
			Else{
				Write-Error $Message.NoEvilPrintQueueForRemove
			}
		}
		Else{
			Write-Error ($Message.NoEvilKeyComputer + " [" + $Computer + "]")
		}
	}
	Else{
		Write-Warning $Message.RunasAdmin
	}
}

Function Get-OSCPrintQueue{
<#
 	.SYNOPSIS
        Get-OSCPrintQueue is a function can be used to list all print queues
		in a computer.
    .DESCRIPTION
        Get-OSCPrintQueue is an advanced function which can be used to list 
		one or all print queues in a computer.
    
	.PARAMETER  <Printer>
    	The printer which you want to get the print queue
		List print queue of the <Printer> in the current computer.
		
	.EXAMPLE
		Get-OSCPrintQueue
		
		List all the print queue in the current computer.
	.EXAMPLE
		Get-OSCPrintQueue -Printer <Printer>
		
		List print queue of the <Printer> in the current computer.
#>

    [CmdletBinding()]
	# Parameters for the function
	PARAM
	(	
	    [Parameter(Mandatory = $false)]
	    [String]$Printer
	)
	
	#Environment params
	[String]$Computer = $Env:COMPUTERNAME
	[Array]$OSCPrintQueues = $null
	[Array]$OSCPrinters = $null 
	[Int]$MatchLen = 0
	# Get all printers of the current computer
	
	$OSCPrinters = Get-OSCPrinter -ErrorAction "silentlycontinue"
		
	# Open base registry key
	Try{
		$BaseKeyPrintQueues = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(`
		[Microsoft.Win32.RegistryHive]::CurrentConfig,$Computer)
	}
	Catch{
		Write-Error ($Message.FailToOpenBaseKey + " ["+ $Computer + "]")
		return $null 
	}
	
	Try{
		$KeyPrintQueues= $BaseKeyPrintQueues.OpenSubKey(`
		"System\CurrentControlSet\Control\Print\Printers", $false)
	}
	Catch{
		Write-Error ($Message.FailToOpenSubKey + " ["+ $Computer + "]")
        return $Null
	}
	
	If ( $KeyPrintQueues.SubKeyCount -gt 0 ) {
		Foreach($KeyPrintQueueName in $KeyPrintQueues.GetSubKeyNames()){
			Try{
				$KeyPrintQueue = $BaseKeyPrintQueues.OpenSubKey(`
				"System\CurrentControlSet\Control\Print\Printers\" `
				+ $KeyPrintQueueName, $false)
			}
			Catch{
				Write-Error ($Message.FailToOpenSubKey +
				" [HKEY_CURRENT_CONFIG\System\CurrentControlSet\Control\" +
				"Print\Printers\" + $KeyPrintQueueName +" ]")
		        return $Null
			}
			
			$KeyPrintQueueValuesList = $KeyPrintQueue.GetValueNames()
			
			If($KeyPrintQueueValuesList -contains 'PrinterOnLine'){
				$ValueType = $KeyPrintQueue.GetValueKind('PrinterOnLine')
				
				If ($ValueType -eq "Dword"){
					If($KeyPrintQueue.GetValue("PrinterOnLine") -eq 0){
						$OSCPrintQueue = New-Object -TypeName PSObject
					    $OSCPrintQueue | Add-Member NoteProperty PrintQueueName `
						$KeyPrintQueue.Name.Replace(
						'HKEY_CURRENT_CONFIG\System\CurrentControlSet\Control\Print\Printers\','')
						$OSCPrintQueue | Add-Member NoteProperty Printer $null
			    		$OSCPrintQueue | Add-Member NoteProperty `
						PrinterDriver $null
						$OSCPrintQueue | Add-Member NoteProperty Computer `
						$Computer
			    		$OSCPrintQueue | Add-Member NoteProperty IsEvilPrintQueue $true   
						
						# Get the printer info of a print queue
						Foreach($OSCPrinter in $OSCPrinters){
							$PrinterName = [String]$OSCPrinter.PrinterName
							$PrintQueueName = $KeyPrintQueueName
							
							If($PrintQueueName -eq $OSCPrinter.PrinterName){
					    		$OSCPrintQueue.Printer = $OSCPrinter.PrinterName
					    		$OSCPrintQueue.PrinterDriver = `
								$OSCPrinter.PrinterDriver
								$OSCPrintQueue.IsEvilPrintQueue = $false 
							}
							Else{
								While($PrintQueueName -match "^.{1,}(\s){1}\(redirected(\s)[1-9][0-9]*\)$"){
									$PrintQueueName = $PrintQueueName.Substring(`
									0,$PrintQueueName.LastIndexof(' (redirected'))
									
									If($PrintQueueName -eq $OSCPrinter.PrinterName){
							    		$OSCPrintQueue.Printer = $OSCPrinter.PrinterName
							    		$OSCPrintQueue.PrinterDriver = `
										$OSCPrinter.PrinterDriver
										$OSCPrintQueue.IsEvilPrintQueue = $false 
										Break
									}
								}
							}
							

						}
						
						$OSCPrintQueues += $OSCPrintQueue
					}
				}
			}
		}
		
		If($OSCPrintQueues.Count -gt 0){
			If($Printer -ne $null -and $Printer -ne ""){
				$OSCPrintQueues = $OSCPrintQueues | `
				Where-Object {$_.PrintQueueName -eq $Printer}
			}
			
			If($OSCPrintQueues.Count -le 0){
				Write-Error ($Message.NoPrintQueueforPrinter + " ["+ $Printer + "]")
			}
		}
		Else{
			Write-Error ($Message.NoPrintQueueComputer + " [" + $Computer + "]")
		}
	}
	Else{
		Write-Error ($Message.PrinterNoneSubKey + " ["+ $Computer + "]")
    }
		
	$OSCPrintQueues 
}

Function Get-OSCPrinter{
<#
 	.SYNOPSIS
        Get-OSCPrinter is a function can be used to list one or all printers in 
		a computer.
    .DESCRIPTION
        Get-OSCPrinter is an advanced function which can be used to list one or
		all printers in a computer.
		
	.PARAMETER  <Printer>
    	The printer which you want to get the information
		Get information of the printer <Printer> in a computer
		
    .EXAMPLE
		Get-OSCPrinter
		
		List information of all printers in the current computer.
    .EXAMPLE
		Get-OSCPrinter -Printer <Printer>
		
		List information of the printer <Printer> in the current computer.
	
	.LINK
		http://msdn.microsoft.com/en-us/library/windows/desktop/aa394363(v=vs.85).aspx
#>

    [CmdletBinding()]
	# Parameters for the function
	PARAM
	(
	    [Parameter(Mandatory = $false)]
	    [String]$Printer
	)
	
	# Environment params
	[String]$Computer = $Env:COMPUTERNAME
	[Array]$OSCPrinters = $null
	[Array]$ObjectPrinters = $null 
	
	Try{
		$ObjectPrinters = Get-Wmiobject -Class " Win32_Printer" `
		-Namespace "root\CIMV2" 
	}
	Catch{
		Write-Error ($Message.FailToConWMI + " ["+ $Computer + "]")
		return $null 
	}
	
	If($ObjectPrinters.Count -gt 0){
	
		# Parameter is not null.
		If($Printer -ne $null -and $Printer -ne ""){
			$ObjectPrinters = $ObjectPrinters | Where-Object {$_.Caption -eq $Printer}
		}
		
		If($ObjectPrinters.Count -gt 0){
		
			# Get printer information
			Foreach($ObjectPrinter in $ObjectPrinters){		
				$OSCPrinter = New-Object -TypeName PSObject
				
			    $OSCPrinter | Add-Member NoteProperty PrinterName `
				$ObjectPrinter.Caption
			    $OSCPrinter | Add-Member NoteProperty PrinterDriver `
				$ObjectPrinter.DriverName
			    $OSCPrinter | Add-Member NoteProperty Computer `
				$Computer
			    $OSCPrinter | Add-Member NoteProperty IsLocalPrinter `
				$ObjectPrinter.Local
			    $OSCPrinter | Add-Member NoteProperty HiddenStatus `
				$ObjectPrinter.Hidden 
				
				$OSCPrinters += $OSCPrinter
			}
		}
		Else{
			Write-Error ($Message.InvalidPrinterName + " ["+ $Printer + "]")
		}
	}
	Else{
		Write-Error ($Message.NoPrinterOnComputer + " ["+ $Computer + "]")
	}
	$OSCPrinters
}

